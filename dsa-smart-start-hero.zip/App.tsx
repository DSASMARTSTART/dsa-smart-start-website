
import React, { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import HeroSection from './components/HeroSection';
import AboutSection from './components/AboutSection';
import MissionSection from './components/MissionSection';
import RootsSection from './components/RootsSection';
import MethodSection from './components/MethodSection';
import PathwaysDetail from './components/PathwaysDetail';
import CareerSection from './components/CareerSection';
import TestimonialsSection from './components/TestimonialsSection';
import Footer from './components/Footer';
import FaqPage from './components/FaqPage';
import WhoWeAre from './components/WhoWeAre';
import ContactPage from './components/ContactPage';
import LoginRegisterPage from './components/LoginRegisterPage';
import CoursesPage from './components/CoursesPage';
import CourseSyllabusPage from './components/CourseSyllabusPage';
import CheckoutPage from './components/CheckoutPage';
import WhatsAppButton from './components/WhatsAppButton';
import DashboardPage from './components/DashboardPage';
import CourseViewer from './components/CourseViewer';

const App: React.FC = () => {
  const [currentPath, setCurrentPath] = useState('home');
  const [selectedCourseId, setSelectedCourseId] = useState<string | null>(null);
  const [cart, setCart] = useState<string[]>([]);
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [user, setUser] = useState<{name: string, email: string} | null>(null);

  // Simple progress storage: courseId_itemKey -> boolean
  const [progress, setProgress] = useState<Record<string, boolean>>(() => {
    const saved = localStorage.getItem('dsa_progress');
    return saved ? JSON.parse(saved) : {};
  });

  useEffect(() => {
    localStorage.setItem('dsa_progress', JSON.stringify(progress));
  }, [progress]);

  // Robust hash routing logic
  useEffect(() => {
    const handleHash = () => {
      const hash = window.location.hash || '#home';
      window.scrollTo({ top: 0, behavior: 'instant' });

      if (hash === '#home') setCurrentPath('home');
      else if (hash === '#faq') setCurrentPath('faq');
      else if (hash === '#who-we-are') setCurrentPath('who-we-are');
      else if (hash === '#contact') setCurrentPath('contact');
      else if (hash === '#login') setCurrentPath('login');
      else if (hash === '#courses') setCurrentPath('courses');
      else if (hash === '#checkout') setCurrentPath('checkout');
      else if (hash === '#dashboard') setCurrentPath('dashboard');
      else if (hash.startsWith('#syllabus-')) {
        setCurrentPath('syllabus');
        setSelectedCourseId(hash.replace('#syllabus-', ''));
      }
      else if (hash.startsWith('#viewer-')) {
        setCurrentPath('viewer');
        setSelectedCourseId(hash.replace('#viewer-', ''));
      }
      else setCurrentPath('home');
    };

    window.addEventListener('hashchange', handleHash);
    handleHash(); 
    return () => window.removeEventListener('hashchange', handleHash);
  }, []);

  const navigateTo = (path: string, params?: string) => {
    if (path === 'syllabus' && params) {
      window.location.hash = `#syllabus-${params}`;
    } else if (path === 'viewer' && params) {
      window.location.hash = `#viewer-${params}`;
    } else if (path === 'home') {
      window.location.hash = '#home';
    } else {
      window.location.hash = `#${path}`;
    }
  };

  const handleLogin = (userData: {name: string, email: string}) => {
    setUser(userData);
    setIsLoggedIn(true);
    navigateTo('dashboard');
  };

  const handleLogout = () => {
    setUser(null);
    setIsLoggedIn(false);
    navigateTo('home');
  };

  const toggleProgress = (courseId: string, itemKey: string) => {
    const key = `${courseId}_${itemKey}`;
    setProgress(prev => ({
      ...prev,
      [key]: !prev[key]
    }));
  };

  const addToCart = (id: string) => {
    if (!cart.includes(id)) {
      setCart(prev => [...prev, id]);
    }
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(item => item !== id));
  };

  const enrollNow = (id: string) => {
    addToCart(id);
    navigateTo('checkout');
  };

  return (
    <main className="min-h-screen bg-white selection:bg-purple-100 selection:text-purple-900 scroll-smooth">
      <Navbar 
        onNavigate={navigateTo} 
        currentPath={currentPath} 
        cartCount={cart.length}
        isLoggedIn={isLoggedIn}
        user={user}
        onLogout={handleLogout}
      />
      
      {currentPath === 'home' && (
        <>
          <HeroSection onNavigate={navigateTo} />
          <div id="about"><AboutSection /></div>
          <MissionSection />
          <div id="roots"><RootsSection /></div>
          <div id="methods"><MethodSection /></div>
          <PathwaysDetail />
          <CareerSection />
          <TestimonialsSection />
        </>
      )}
      
      {currentPath === 'faq' && <FaqPage />}
      {currentPath === 'who-we-are' && <WhoWeAre />}
      {currentPath === 'contact' && <ContactPage />}
      {currentPath === 'login' && <LoginRegisterPage onLogin={handleLogin} />}
      
      {currentPath === 'courses' && (
        <CoursesPage 
          onSelectCourse={(id) => navigateTo('syllabus', id)} 
          onEnroll={enrollNow}
          cart={cart}
          onAddToCart={addToCart}
        />
      )}

      {currentPath === 'syllabus' && selectedCourseId && (
        <CourseSyllabusPage 
          courseId={selectedCourseId} 
          onBack={() => navigateTo('courses')} 
          onEnroll={enrollNow}
          onAddToCart={addToCart}
          isInCart={cart.includes(selectedCourseId)}
        />
      )}

      {currentPath === 'checkout' && (
        <CheckoutPage 
          cart={cart}
          onBack={() => navigateTo('courses')} 
          onRemoveItem={removeFromCart}
          onClearCart={() => setCart([])}
          onBrowse={() => navigateTo('courses')}
        />
      )}

      {currentPath === 'dashboard' && (
        <DashboardPage 
          user={user} 
          progress={progress} 
          onOpenCourse={(id) => navigateTo('viewer', id)}
        />
      )}

      {currentPath === 'viewer' && selectedCourseId && (
        <CourseViewer 
          courseId={selectedCourseId}
          progress={progress}
          onToggleProgress={toggleProgress}
          onBack={() => navigateTo('dashboard')}
        />
      )}
      
      <Footer onNavigate={navigateTo} />
      <WhatsAppButton />
    </main>
  );
};

export default App;
