
import React, { useEffect, useRef, useState } from 'react';
import { Layers, Compass, Zap, Music, Play, Award, Star, ChevronRight, CheckCircle2, Clock, Sparkles, BookOpen, ShoppingCart, Check, Rocket, Shield, ArrowDown } from 'lucide-react';

const CourseCard: React.FC<{ 
  id: string;
  name: string; 
  level: string; 
  icon: React.ReactNode; 
  color: string; 
  desc: string; 
  features: string[]; 
  duration: string;
  price: string;
  originalPrice?: string;
  image: string;
  isPink?: boolean;
  isPopular?: boolean;
  isFeatured?: boolean;
  isInCart?: boolean;
  onSelect: (id: string) => void;
  onEnroll: (id: string) => void;
  onAddToCart: (id: string) => void;
}> = ({ id, name, level, icon, color, desc, features, duration, price, originalPrice, image, isPink, isPopular, isFeatured, isInCart, onSelect, onEnroll, onAddToCart }) => (
  <div className={`group relative bg-white rounded-[3rem] border transition-all duration-500 flex flex-col h-full animate-reveal overflow-hidden ${isFeatured ? 'border-purple-200 ring-2 ring-purple-500/10 shadow-xl shadow-purple-500/10' : 'border-gray-100 shadow-sm hover:shadow-2xl hover:shadow-purple-500/10'}`}>
    {/* Course Image Container */}
    <div className="relative h-48 overflow-hidden shrink-0">
      <img src={image} alt={name} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-700" />
      <div className={`absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent opacity-60`}></div>
      
      {/* Status Badges */}
      <div className="absolute top-4 right-4 flex flex-col gap-2 items-end">
        {isPopular && (
          <div className={`px-3 py-1.5 rounded-full text-[8px] font-black uppercase tracking-[0.2em] text-white shadow-xl z-20 animate-bounce ${isPink ? 'bg-gradient-to-r from-pink-500 to-rose-500' : 'bg-gradient-to-r from-purple-500 to-indigo-600'}`}>
            Most Popular
          </div>
        )}
        {isFeatured && (
          <div className="px-3 py-1.5 rounded-full text-[8px] font-black uppercase tracking-[0.2em] text-white shadow-xl z-20 bg-gradient-to-r from-amber-400 to-orange-500">
            Featured Path
          </div>
        )}
      </div>
    </div>

    {/* Floating Icon - Outside overflow-hidden to prevent clipping */}
    <div className={`absolute top-48 left-8 w-14 h-14 -translate-y-1/2 rounded-2xl bg-gradient-to-br ${color} text-white flex items-center justify-center shadow-2xl border-4 border-white transform group-hover:-translate-y-2/3 transition-transform duration-500 z-30`}>
      {React.cloneElement(icon as React.ReactElement, { size: 24 })}
    </div>

    {/* Content Area */}
    <div className="p-8 md:p-10 pt-12 flex flex-col flex-grow relative z-10 bg-white">
      <div className="mb-6">
        <div className="flex justify-between items-start mb-2">
          <span className={`text-[10px] font-black uppercase tracking-[0.2em] block ${isPink ? 'text-pink-500' : 'text-purple-500'}`}>
            {level}
          </span>
          <div className="flex items-center gap-1.5 px-3 py-1 bg-gray-50 rounded-full border border-gray-100">
            <Clock size={12} className="text-gray-400" />
            <span className="text-[9px] font-bold text-gray-500 uppercase tracking-widest">{duration}</span>
          </div>
        </div>
        <h5 className="text-2xl font-black text-gray-900 tracking-tight leading-tight">DSA SMART START {name}</h5>
      </div>

      <div className="mb-6">
        <div className="flex items-baseline gap-2">
          <span className="text-3xl font-black text-gray-900">{price}</span>
          {originalPrice && (
            <span className="text-sm font-bold text-gray-400 line-through decoration-pink-500">{originalPrice}</span>
          )}
        </div>
        <span className="text-[10px] font-black text-purple-600 uppercase tracking-widest">Limited Time Offer</span>
      </div>

      <p className="text-gray-600 leading-relaxed mb-8 text-sm flex-grow font-medium line-clamp-4">
        {desc}
      </p>

      <div className="space-y-3 mb-10">
        {features.map((f, i) => (
          <div key={i} className="flex items-center gap-3">
            <CheckCircle2 size={16} className={isPink ? 'text-pink-500' : 'text-purple-500'} />
            <span className="text-xs font-bold text-gray-700">{f}</span>
          </div>
        ))}
      </div>

      {/* Actions */}
      <div className="flex flex-col gap-3 mb-6">
        <button 
          onClick={() => onEnroll(id)}
          className={`w-full flex items-center justify-center py-4 rounded-2xl font-black text-[10px] uppercase tracking-widest text-white shadow-xl transition-all active:scale-95 ${isPink ? 'bg-pink-600 hover:bg-pink-700 shadow-pink-100' : 'bg-purple-600 hover:bg-purple-700 shadow-purple-100'}`}
        >
          ENROLL FOR {price}
        </button>
        <button 
          onClick={() => onAddToCart(id)}
          className={`w-full flex items-center justify-center gap-2 py-3 rounded-2xl font-black text-[9px] uppercase tracking-[0.2em] border-2 transition-all active:scale-95 ${isInCart ? 'border-green-500 text-green-500 bg-green-50' : 'border-gray-100 text-gray-400 hover:border-purple-200 hover:text-purple-600'}`}
        >
          {isInCart ? (
            <>
              <Check size={14} />
              Added to Cart
            </>
          ) : (
            <>
              <ShoppingCart size={14} />
              Add to Cart
            </>
          )}
        </button>
      </div>

      {/* Secondary Action & Rating */}
      <div className="pt-6 border-t border-gray-50 flex items-center justify-between">
        <button 
          onClick={() => onSelect(id)}
          className={`text-[11px] font-black uppercase tracking-widest flex items-center gap-2 group-hover:gap-4 transition-all ${isPink ? 'text-pink-600' : 'text-purple-600'}`}
        >
          View Syllabus
          <ChevronRight size={14} />
        </button>
        <div className="flex gap-1">
          {[...Array(5)].map((_, i) => <Star key={i} size={10} className="fill-yellow-400 text-yellow-400" />)}
        </div>
      </div>
    </div>
  </div>
);

interface CoursesPageProps {
  onSelectCourse: (id: string) => void;
  onEnroll: (id: string) => void;
  cart: string[];
  onAddToCart: (id: string) => void;
}

const CoursesPage: React.FC<CoursesPageProps> = ({ onSelectCourse, onEnroll, cart, onAddToCart }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const { clientX, clientY } = e;
      const moveX = (clientX - window.innerWidth / 2) / 40;
      const moveY = (clientY - window.innerHeight / 2) / 40;
      setMousePos({ x: moveX, y: moveY });
    };
    window.addEventListener('mousemove', handleMouseMove);

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let particles: { x: number; y: number; size: number; speedX: number; speedY: number; opacity: number }[] = [];
    const particleCount = 40;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      particles = Array.from({ length: particleCount }, () => ({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size: Math.random() * 2 + 1,
        speedX: (Math.random() - 0.5) * 0.3,
        speedY: (Math.random() - 0.5) * 0.3,
        opacity: Math.random() * 0.5 + 0.1,
      }));
    };

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particles.forEach((p) => {
        p.x += p.speedX;
        p.y += p.speedY;
        if (p.x > canvas.width) p.x = 0;
        if (p.x < 0) p.x = canvas.width;
        if (p.y > canvas.height) p.y = 0;
        if (p.y < 0) p.y = canvas.height;
        ctx.fillStyle = `rgba(168, 85, 247, ${p.opacity})`;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      });
      animationFrameId = requestAnimationFrame(animate);
    };

    window.addEventListener('resize', resize);
    resize();
    animate();
    return () => {
      window.removeEventListener('resize', resize);
      window.removeEventListener('mousemove', handleMouseMove);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  const featuredCourses = [
    {
      id: "premium-path",
      name: "- PREMIUM PATH",
      level: "Elite Training",
      icon: <Rocket size={28} />,
      color: "from-purple-600 to-indigo-800",
      duration: "Lifetime",
      price: "730.00€",
      originalPrice: "1,050.00€",
      image: "https://images.unsplash.com/photo-1516321318423-f06f85e504b3?auto=format&fit=crop&q=80&w=800",
      isFeatured: true,
      desc: "Our most comprehensive premium learning path. Complete mastery of English for dyslexic professionals and high-achievers with visual, inclusive tools.",
      features: ["All-Access Pass", "Priority Specialist Support", "Advanced Executive Coaching"]
    },
    {
      id: "gold-path",
      name: "- GOLD PATH",
      level: "Professional",
      icon: <Shield size={28} />,
      color: "from-amber-400 to-amber-600",
      duration: "24 Months",
      price: "626.00€",
      originalPrice: "950.00€",
      image: "https://images.unsplash.com/photo-1552664730-d307ca884978?auto=format&fit=crop&q=80&w=800",
      isFeatured: true,
      desc: "The gold standard for language fluency. A structured, deep-dive path into English communication excellence using personalized strategies.",
      features: ["Certification Prep", "Bespoke Study Plans", "Weekly Masterclasses"]
    }
  ];

  const adultCourses = [
    { 
      id: "a1",
      name: "A1 LEVEL", 
      level: "Beginner", 
      icon: <Layers size={28} />, 
      color: "from-blue-500 to-indigo-600", 
      duration: "12 Weeks",
      price: "50.00€",
      originalPrice: "100.00€",
      image: "https://images.unsplash.com/photo-1546410531-bb4caa6b424d?auto=format&fit=crop&q=80&w=800",
      desc: "First steps for students with DSA. A visual, multisensory approach to facilitate comprehension and active use following Cambridge A1 prep.",
      features: ["Visual Vocabulary Maps", "Basic Sentence Architecture", "Phonetic Awareness"]
    },
    { 
      id: "a2",
      name: "A2 LEVEL", 
      level: "Elementary", 
      icon: <Compass size={28} />, 
      color: "from-indigo-500 to-purple-600", 
      duration: "16 Weeks",
      price: "1.00€",
      originalPrice: "10.00€",
      isPopular: true,
      image: "https://images.unsplash.com/photo-1503676260728-1c00da094a0b?auto=format&fit=crop&q=80&w=800",
      desc: "Consolidate skills and introduce complex structures. Ideal for Cambridge KET preparation with high-legibility worksheets and symbols.",
      features: ["Scenario-based Learning", "Grammar Visualizations", "Listening Drills"]
    },
    { 
      id: "b1",
      name: "B1 LEVEL", 
      level: "Intermediate", 
      icon: <Zap size={28} />, 
      color: "from-purple-600 to-pink-600", 
      duration: "20 Weeks",
      price: "50.00€",
      originalPrice: "100.00€",
      image: "https://images.unsplash.com/photo-1434030216411-0b793f4b4173?auto=format&fit=crop&q=80&w=800",
      desc: "Language becomes a complex communication tool. Develop all four skills (listening, reading, writing, speaking) for Cambridge PET level.",
      features: ["Academic Prep", "Fluency Workshops", "Strategic Reading Tools"]
    },
  ];

  const kidsCourses = [
    { 
      id: "kids-basic",
      name: "KIDS BASIC", 
      level: "Early Years", 
      icon: <Music size={28} />, 
      color: "from-pink-400 to-rose-500", 
      duration: "8 Weeks",
      price: "19.00€",
      image: "https://images.unsplash.com/photo-1502086223501-7ea6ecd79368?auto=format&fit=crop&q=80&w=800",
      desc: "Step-by-step guidance starting from A1 Starters. Focused on building confidence and basic communication for the youngest learners.",
      features: ["Musical Mnemonics", "Sensory Play", "Confidence Building"]
    },
    { 
      id: "kids-medium",
      name: "KIDS MEDIUM", 
      level: "Primary", 
      icon: <Play size={28} />, 
      color: "from-rose-500 to-orange-500", 
      duration: "12 Weeks",
      price: "39.00€",
      image: "https://images.unsplash.com/photo-1484820540004-14229fe36ca4?auto=format&fit=crop&q=80&w=800",
      desc: "Expanding vocabulary and improving sentence structure. Focus on reading and listening comprehension through engaging multisensory tools.",
      features: ["Vocabulary Games", "Interactive Storytelling", "Reading Maps"]
    },
    { 
      id: "kids-advanced",
      name: "KIDS ADVANCED", 
      level: "Pre-Teen", 
      icon: <Award size={28} />, 
      color: "from-orange-500 to-amber-500", 
      duration: "16 Weeks",
      price: "70.00€",
      originalPrice: "150.00€",
      isPopular: true,
      image: "https://images.unsplash.com/photo-1516534775068-ba3e84529519?auto=format&fit=crop&q=80&w=800",
      desc: "Preparation for Cambridge A2 Flyers exam. Develop structured and confident language for realistic dialogues and short stories.",
      features: ["Exam Success", "Confident Dialogue", "Realistic Scenarios"]
    }
  ];

  return (
    <div className="bg-white min-h-screen">
      {/* Hero Header Section */}
      <div className="relative w-full h-[65vh] min-h-[550px] flex flex-col items-center justify-center overflow-hidden bg-[#f8f5ff]">
        <div className="absolute inset-0 z-0">
          <canvas ref={canvasRef} className="absolute inset-0 z-0 pointer-events-none" />
          <div className="absolute inset-0 opacity-15 pointer-events-none" 
               style={{ backgroundImage: `repeating-linear-gradient(90deg, transparent, transparent 45px, rgba(255, 255, 255, 0.4) 50px, transparent 55px, transparent 100px)`, filter: 'blur(30px)' }} />
        </div>

        <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 flex flex-col items-center text-center transition-transform duration-300 ease-out"
             style={{ transform: `translate(${mousePos.x * 0.1}px, ${mousePos.y * 0.1}px)` }}>
          
          <div className="flex items-center gap-4 mb-6 opacity-60 animate-reveal">
            <div className="h-[1.5px] w-12 bg-purple-400"></div>
            <span className="text-[10px] sm:text-[11px] font-black uppercase tracking-[0.4em] text-gray-800">
              Education Pathways
            </span>
            <div className="h-[1.5px] w-12 bg-purple-400"></div>
          </div>

          <div className="relative flex flex-col items-center mb-8 sm:mb-10 group cursor-default w-full">
            <h1 className="flex flex-wrap items-center justify-center gap-x-2 sm:gap-x-4 text-4xl sm:text-6xl md:text-8xl lg:text-[10rem] font-black text-[#1a1c2d] tracking-tighter leading-none animate-reveal transition-transform duration-500 overflow-visible"
                style={{ transform: `translate(${mousePos.x * 0.4}px, ${mousePos.y * 0.4}px)` }}>
              <span className="uppercase">LEARNING</span>
              <span className="inline-block px-2 sm:px-4 italic text-transparent bg-clip-text bg-gradient-to-r from-[#9b4dff] via-[#8a3ffc] to-[#ff2d85] drop-shadow-sm select-none">
                COURSES
              </span>
            </h1>
          </div>

          <div className="max-w-2xl animate-reveal stagger-2 mt-4 px-4" style={{ transform: `translate(${mousePos.x * 0.2}px, ${mousePos.y * 0.2}px)` }}>
            <p className="text-lg sm:text-xl md:text-2xl font-light italic text-gray-700 tracking-tight leading-tight px-4 mb-10">
              Scientifically designed for the dyslexic mind. Find your path to success.
            </p>
            <button 
              onClick={() => document.getElementById('course-list')?.scrollIntoView({ behavior: 'smooth' })}
              className="group inline-flex items-center gap-4 bg-[#8a3ffc] text-white px-12 py-5 rounded-full font-black text-xs uppercase tracking-widest shadow-2xl shadow-purple-500/30 hover:scale-110 active:scale-95 transition-all"
            >
              CHOOSE A COURSE
              <ArrowDown size={18} className="group-hover:translate-y-1 transition-transform" />
            </button>
          </div>
        </div>

        {/* Curved Bottom Mask */}
        <div 
          className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[160%] h-[150px] sm:h-[200px] bg-white z-20"
          style={{ borderRadius: '100% 100% 0 0', transform: 'translateX(-50%) translateY(50%)' }}
        />
      </div>

      {/* Course Categories */}
      <section id="course-list" className="py-24 px-6 relative z-30">
        <div className="max-w-7xl mx-auto">
          
          {/* Featured Paths Section */}
          <div className="mb-40">
            <div className="flex flex-col md:flex-row items-end justify-between mb-16 gap-8 animate-reveal">
              <div className="max-w-2xl">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 bg-amber-50 rounded-xl flex items-center justify-center text-amber-600 border border-amber-100">
                    <Star size={20} />
                  </div>
                  <h3 className="text-3xl md:text-5xl font-black text-gray-900 tracking-tighter uppercase">Featured Paths</h3>
                </div>
                <p className="text-gray-500 text-lg font-medium leading-relaxed">
                  The ultimate choice for dedicated learners. These paths offer complete coverage and professional-grade support.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
              {featuredCourses.map((course, i) => (
                <CourseCard 
                  key={i} 
                  {...course} 
                  onSelect={onSelectCourse} 
                  onEnroll={onEnroll} 
                  onAddToCart={onAddToCart}
                  isInCart={cart.includes(course.id)}
                />
              ))}
            </div>
          </div>

          {/* Adults & Teens Section */}
          <div className="mb-40">
            <div className="flex flex-col md:flex-row items-end justify-between mb-16 gap-8 animate-reveal">
              <div className="max-w-2xl">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 bg-indigo-50 rounded-xl flex items-center justify-center text-indigo-600 border border-indigo-100">
                    <BookOpen size={20} />
                  </div>
                  <h3 className="text-3xl md:text-5xl font-black text-gray-900 tracking-tighter uppercase">Adults & Teens</h3>
                </div>
                <p className="text-gray-500 text-lg font-medium leading-relaxed">
                  Standard levels designed for specific CEFR milestones. Fast-track your learning with our specialized DSA techniques.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-12">
              {adultCourses.map((course, i) => (
                <CourseCard 
                  key={i} 
                  {...course} 
                  onSelect={onSelectCourse} 
                  onEnroll={onEnroll} 
                  onAddToCart={onAddToCart}
                  isInCart={cart.includes(course.id)}
                />
              ))}
            </div>
          </div>

          {/* Kids Section */}
          <div>
            <div className="flex flex-col md:flex-row items-end justify-between mb-16 gap-8 animate-reveal">
              <div className="max-w-2xl">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-10 h-10 bg-pink-50 rounded-xl flex items-center justify-center text-pink-600 border border-pink-100">
                    <Sparkles size={20} />
                  </div>
                  <h3 className="text-3xl md:text-5xl font-black text-gray-900 tracking-tighter uppercase">Kids Program</h3>
                </div>
                <p className="text-gray-500 text-lg font-medium leading-relaxed">
                  Gamified and multisensory learning paths to make English a fun adventure for children.
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-12">
              {kidsCourses.map((course, i) => (
                <CourseCard 
                  key={i} 
                  {...course} 
                  isPink 
                  onSelect={onSelectCourse} 
                  onEnroll={onEnroll} 
                  onAddToCart={onAddToCart}
                  isInCart={cart.includes(course.id)}
                />
              ))}
            </div>
          </div>

          {/* Bottom Buy/Enroll CTA */}
          <div className="mt-40 text-center animate-reveal">
             <div className="bg-[#0f172a] rounded-[4rem] p-12 md:p-24 relative overflow-hidden group">
               <div className="absolute top-0 right-0 w-96 h-96 bg-purple-600/10 rounded-full blur-[100px] -translate-y-1/2 translate-x-1/2"></div>
               <div className="absolute bottom-0 left-0 w-96 h-96 bg-blue-600/10 rounded-full blur-[100px] translate-y-1/2 -translate-x-1/2"></div>
               
               <div className="relative z-10 max-w-3xl mx-auto">
                 <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 mb-8">
                    <Rocket size={16} className="text-purple-400" />
                    <span className="text-[10px] font-black uppercase tracking-[0.3em] text-purple-400">Start Your Success Story</span>
                 </div>
                 <h4 className="text-3xl md:text-6xl font-black text-white mb-8 leading-tight tracking-tight uppercase">
                    Ready to master <br /> the English language?
                 </h4>
                 <p className="text-gray-400 text-xl mb-12 font-medium">
                    Join thousands of successful DSA students. Secure your spot in our specialized programs today.
                 </p>
                 <div className="flex flex-col sm:flex-row gap-6 justify-center">
                    <button 
                      onClick={() => document.getElementById('course-list')?.scrollIntoView({ behavior: 'smooth' })}
                      className="flex items-center justify-center gap-3 bg-white text-gray-900 px-12 py-5 rounded-full font-black text-xs uppercase tracking-widest hover:bg-purple-500 hover:text-white transition-all shadow-2xl active:scale-95"
                    >
                      ENROLL IN A COURSE
                      <ChevronRight size={18} />
                    </button>
                    <button 
                      className="flex items-center justify-center gap-3 bg-white/5 border border-white/10 text-white px-12 py-5 rounded-full font-black text-xs uppercase tracking-widest hover:bg-white/10 transition-all active:scale-95"
                    >
                      FREE CONSULTATION
                    </button>
                 </div>
               </div>
             </div>
          </div>
        </div>
      </section>

      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes spin-slow {
          from { transform: rotate(0deg); }
          to { transform: rotate(360deg); }
        }
        .animate-spin-slow {
          animation: spin-slow 8s linear infinite;
        }
      `}} />
    </div>
  );
};

export default CoursesPage;
