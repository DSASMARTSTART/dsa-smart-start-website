
import React from 'react';
// Add missing CheckCircle2 to imports
import { Rocket, Clock, ChevronRight, Star, BookOpen, Layout, Zap, Layers, Compass, Music, Play, Award, CheckCircle2 } from 'lucide-react';

interface DashboardProps {
  user: { name: string, email: string } | null;
  progress: Record<string, boolean>;
  onOpenCourse: (id: string) => void;
}

const DashboardPage: React.FC<DashboardProps> = ({ user, progress, onOpenCourse }) => {
  // Real item counts based on the syllabus (15 units/lessons + homework sets)
  // A1: 15 Units + 3 Homework Sets = 18 total items
  // A2: 15 Units + 1 Homework Set = 16 total items
  const COURSE_METADATA = {
    "a1": { total: 18 },
    "a2": { total: 16 }
  };

  const MY_COURSES = [
    { 
      id: "a1", 
      name: "A1 LEVEL", 
      level: "Beginner", 
      icon: <Layers size={22} />, 
      color: "from-blue-500 to-indigo-600", 
      items: COURSE_METADATA["a1"].total 
    },
    { 
      id: "a2", 
      name: "A2 LEVEL", 
      level: "Elementary", 
      icon: <Compass size={22} />, 
      color: "from-indigo-500 to-purple-600", 
      items: COURSE_METADATA["a2"].total 
    },
  ];

  const calculateProgress = (courseId: string, totalItems: number) => {
    // Count only the keys belonging to this course that are marked as true
    const completedCount = Object.keys(progress).filter(key => 
      key.startsWith(`${courseId}_`) && progress[key]
    ).length;
    
    // Calculate percentage based on actual content count
    return Math.min(100, Math.round((completedCount / totalItems) * 100));
  };

  return (
    <div className="bg-[#f8f9fb] min-h-screen pt-32 pb-20">
      <div className="max-w-7xl mx-auto px-6">
        
        {/* Welcome Header */}
        <div className="mb-12 animate-reveal">
          <div className="flex items-center gap-3 mb-4">
            <span className="text-[10px] font-black uppercase tracking-[0.3em] text-purple-500 px-3 py-1 bg-purple-50 rounded-full border border-purple-100">Student Dashboard</span>
          </div>
          <h1 className="text-4xl md:text-6xl font-black text-gray-900 tracking-tighter uppercase leading-tight mb-2">
            Welcome back, <span className="text-purple-600">{user?.name || 'Student'}</span>!
          </h1>
          <p className="text-gray-500 text-lg font-medium italic">Keep pushing forward. Your neurodiversity is your superpower.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          
          {/* Main Content - Courses */}
          <div className="lg:col-span-8 space-y-10">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-black text-gray-900 uppercase tracking-widest flex items-center gap-3">
                <BookOpen size={20} className="text-purple-600" />
                My Learning Path
              </h2>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
              {MY_COURSES.map((course, idx) => {
                const completion = calculateProgress(course.id, course.items);
                return (
                  <div key={course.id} className="group bg-white rounded-[3rem] border border-gray-100 shadow-sm hover:shadow-2xl hover:shadow-purple-500/5 transition-all duration-500 p-10 flex flex-col animate-reveal" style={{ animationDelay: `${idx * 0.1}s` }}>
                    <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${course.color} text-white flex items-center justify-center mb-8 shadow-lg shadow-purple-100`}>
                      {course.icon}
                    </div>
                    <div className="mb-8">
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-[10px] font-black uppercase tracking-widest text-purple-400">{course.level}</span>
                        {completion === 100 && (
                          <span className="text-[9px] font-black text-green-500 uppercase tracking-widest flex items-center gap-1">
                            <Star size={10} fill="currentColor" />
                            Completed
                          </span>
                        )}
                      </div>
                      <h3 className="text-2xl font-black text-gray-900 tracking-tight uppercase leading-none">DSA SMART START {course.name}</h3>
                    </div>
                    
                    <div className="mb-10">
                      <div className="flex justify-between items-end mb-3">
                        <span className="text-[10px] font-black uppercase tracking-widest text-gray-400">Real Progress</span>
                        <span className="text-sm font-black text-gray-900">{completion}%</span>
                      </div>
                      <div className="h-3 bg-gray-50 rounded-full overflow-hidden border border-gray-100">
                        <div 
                          className={`h-full bg-gradient-to-r ${course.color} transition-all duration-1000 ease-out`}
                          style={{ width: `${completion}%` }}
                        ></div>
                      </div>
                    </div>

                    <button 
                      onClick={() => onOpenCourse(course.id)}
                      className="flex items-center justify-center gap-3 w-full py-4 rounded-2xl bg-gray-900 text-white font-black text-[10px] uppercase tracking-widest hover:bg-purple-600 transition-all active:scale-95"
                    >
                      {completion === 100 ? 'REVIEW CONTENT' : 'CONTINUE LEARNING'}
                      <ChevronRight size={16} />
                    </button>
                  </div>
                );
              })}

              {/* Browse New Courses Placeholder */}
              <div className="bg-white/50 border-2 border-dashed border-gray-200 rounded-[3rem] p-10 flex flex-col items-center justify-center text-center animate-reveal stagger-2">
                <div className="w-14 h-14 rounded-2xl bg-gray-100 text-gray-400 flex items-center justify-center mb-6">
                  <Star size={24} />
                </div>
                <h4 className="text-lg font-black text-gray-400 uppercase tracking-tight mb-2">Next Path?</h4>
                <p className="text-xs font-bold text-gray-400 mb-8 max-w-[150px]">Finish your current path to unlock advanced certificates.</p>
                <button 
                  onClick={() => window.location.hash = '#courses'}
                  className="text-[10px] font-black uppercase tracking-widest text-purple-600 hover:underline"
                >
                  Browse Catalog
                </button>
              </div>
            </div>
          </div>

          {/* Sidebar - Stats & Activity */}
          <div className="lg:col-span-4 space-y-8 animate-reveal stagger-1">
            <div className="bg-white rounded-[3rem] border border-gray-100 p-10 shadow-sm">
              <h3 className="text-lg font-black text-gray-900 uppercase tracking-widest mb-8 flex items-center gap-3">
                <Zap size={20} className="text-amber-500" />
                Live Stats
              </h3>
              <div className="space-y-6">
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-purple-50 rounded-xl flex items-center justify-center text-purple-600 border border-purple-100">
                    <CheckCircle2 size={18} />
                  </div>
                  <div>
                    <p className="text-[10px] font-black uppercase text-gray-400 tracking-widest">Items Completed</p>
                    <p className="text-xl font-black text-gray-900">
                      {Object.values(progress).filter(v => v).length} Total
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-10 h-10 bg-pink-50 rounded-xl flex items-center justify-center text-pink-600 border border-pink-100">
                    <Rocket size={18} />
                  </div>
                  <div>
                    <p className="text-[10px] font-black uppercase text-gray-400 tracking-widest">Current Status</p>
                    <p className="text-xl font-black text-gray-900">Active Learner</p>
                  </div>
                </div>
              </div>
            </div>

            <div className="bg-gradient-to-br from-[#1a1c2d] to-black rounded-[3rem] p-10 text-white relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-32 h-32 bg-purple-600/20 rounded-full blur-[60px] translate-x-1/2 -translate-y-1/2"></div>
              <h3 className="text-lg font-black uppercase tracking-widest mb-6 relative z-10">Study Group</h3>
              <p className="text-gray-400 text-sm leading-relaxed mb-8 relative z-10">Connect with other DSA students in our private community.</p>
              <button className="relative z-10 w-full py-4 rounded-2xl bg-white/10 border border-white/20 text-white font-black text-[10px] uppercase tracking-widest hover:bg-white/20 transition-all">
                JOIN COMMUNITY
              </button>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
};

export default DashboardPage;
