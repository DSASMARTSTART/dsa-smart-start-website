
import React, { useEffect, useRef, useState } from 'react';
import { ArrowUpRight, ArrowDownRight, ChevronRight } from 'lucide-react';

interface HeroProps {
  onNavigate?: (path: string) => void;
}

const HeroSection: React.FC<HeroProps> = ({ onNavigate }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const { clientX, clientY } = e;
      const moveX = (clientX - window.innerWidth / 2) / 50;
      const moveY = (clientY - window.innerHeight / 2) / 50;
      setMousePos({ x: moveX, y: moveY });
    };
    window.addEventListener('mousemove', handleMouseMove);

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let particles: { x: number; y: number; size: number; speedX: number; speedY: number; opacity: number }[] = [];
    const particleCount = 40;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      particles = Array.from({ length: particleCount }, () => ({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size: Math.random() * 2 + 1,
        speedX: (Math.random() - 0.5) * 0.3,
        speedY: (Math.random() - 0.5) * 0.3,
        opacity: Math.random() * 0.5 + 0.1,
      }));
    };

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particles.forEach((p) => {
        p.x += p.speedX;
        p.y += p.speedY;
        if (p.x > canvas.width) p.x = 0;
        if (p.x < 0) p.x = canvas.width;
        if (p.y > canvas.height) p.y = 0;
        if (p.y < 0) p.y = canvas.height;
        ctx.fillStyle = `rgba(168, 85, 247, ${p.opacity})`;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      });
      animationFrameId = requestAnimationFrame(animate);
    };

    window.addEventListener('resize', resize);
    resize();
    animate();
    return () => {
      window.removeEventListener('resize', resize);
      window.removeEventListener('mousemove', handleMouseMove);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <div className="relative w-full h-screen min-h-[700px] flex flex-col items-center justify-center overflow-hidden bg-[#f3e8ff]">
      <div className="absolute inset-0 z-0">
        <canvas ref={canvasRef} className="absolute inset-0 z-0 pointer-events-none" />
        <div className="absolute inset-0 opacity-20 pointer-events-none" 
             style={{ backgroundImage: `repeating-linear-gradient(90deg, transparent, transparent 45px, rgba(255, 255, 255, 0.4) 50px, transparent 55px, transparent 100px)`, filter: 'blur(30px)' }} />
      </div>

      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 flex flex-col items-center text-center -translate-y-6 sm:-translate-y-12 transition-transform duration-300 ease-out"
           style={{ transform: `translate(${mousePos.x * 0.2}px, ${mousePos.y * 0.2}px)` }}>
        
        <div className="flex items-center gap-4 mb-6 sm:mb-8 opacity-60 animate-reveal">
          <div className="h-[1px] w-6 sm:w-8 bg-purple-400"></div>
          <span className="text-[9px] sm:text-[10px] font-bold uppercase tracking-[0.4em] text-gray-800">Pioneering DSA Excellence</span>
          <div className="h-[1px] w-6 sm:w-8 bg-purple-400"></div>
        </div>

        <div className="relative flex flex-col items-center mb-6 w-full">
          <div className="hidden lg:flex absolute -left-32 top-0 items-center gap-3 bg-white/80 backdrop-blur px-5 py-3 rounded-2xl shadow-lg transform -rotate-3 animate-reveal stagger-1 border border-white hover:scale-110 transition-transform cursor-pointer group"
               style={{ transform: `translate(${mousePos.x * -1}px, ${mousePos.y * -1}px) rotate(-3deg)` }}>
            <div className="w-8 h-8 bg-[#ffcc00] rounded-lg flex items-center justify-center shadow-inner">
              <ArrowDownRight size={16} className="text-gray-900" />
            </div>
            <div className="text-left">
              <p className="text-[8px] font-black uppercase text-gray-400 leading-none mb-1">Methodology</p>
              <p className="text-xs font-black text-gray-900 leading-none">DSA SMART START</p>
            </div>
          </div>

          <h1 className="flex flex-wrap items-center justify-center gap-x-4 gap-y-0 text-5xl sm:text-7xl md:text-9xl lg:text-[11rem] font-black text-[#1a1c2d] tracking-tighter leading-[0.9] sm:leading-none animate-reveal transition-transform duration-500"
              style={{ transform: `translate(${mousePos.x * 0.5}px, ${mousePos.y * 0.5}px)` }}>
            <span>DSA</span>
            <span className="text-transparent bg-clip-text bg-gradient-to-br from-pink-400 to-purple-500 italic font-medium px-2 sm:px-4">&</span>
            <span>English</span>
          </h1>

          <div className="hidden lg:flex absolute -right-40 bottom-0 items-center gap-3 bg-white/80 backdrop-blur px-5 py-3 rounded-2xl shadow-lg transform rotate-3 animate-reveal stagger-2 border border-white hover:scale-110 transition-transform cursor-pointer group"
               style={{ transform: `translate(${mousePos.x * 0.8}px, ${mousePos.y * 0.8}px) rotate(3deg)` }}>
            <div className="w-8 h-8 bg-[#8a3ffc] rounded-lg flex items-center justify-center shadow-inner">
              <ArrowUpRight size={16} className="text-white" />
            </div>
            <div className="text-left">
              <p className="text-[8px] font-black uppercase text-gray-400 leading-none mb-1">Premium</p>
              <p className="text-xs font-black text-gray-900 leading-none">English Course</p>
            </div>
          </div>
        </div>

        <div className="flex flex-col items-center animate-reveal stagger-1 transition-transform duration-700"
             style={{ transform: `translate(${mousePos.x * 0.3}px, ${mousePos.y * 0.3}px)` }}>
          <p className="text-xl sm:text-3xl md:text-5xl font-light italic text-gray-700 tracking-[0.1em] mb-2 text-center uppercase">
            TAILOR-MADE METHOD FOR
          </p>
          <p className="text-3xl sm:text-4xl md:text-6xl font-black italic text-[#8a3ffc] tracking-tight mb-6 sm:mb-8 text-center uppercase">
            DYSLEXIA
          </p>
          <p className="text-lg sm:text-xl md:text-2xl font-medium text-gray-600 mb-8 sm:mb-10 text-center px-4">
            Learning English Made Effortless
          </p>
        </div>

        <div className="animate-reveal stagger-2">
          <button 
            onClick={() => onNavigate?.('courses')}
            className="group flex items-center gap-3 bg-[#8a3ffc] text-white px-10 sm:px-14 py-4 sm:py-5 rounded-full font-black text-[10px] sm:text-xs tracking-[0.2em] shadow-2xl shadow-purple-500/40 transition-all duration-300 transform hover:scale-110 active:scale-95 uppercase"
          >
            BOOK NOW
            <ChevronRight size={18} className="group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </div>

      <div 
        className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[160%] h-[200px] sm:h-[300px] bg-white z-20"
        style={{ borderRadius: '100% 100% 0 0', transform: 'translateX(-50%) translateY(50%)' }}
      />
    </div>
  );
};

export default HeroSection;
