
import React, { useEffect, useRef, useState } from 'react';
import { Mail, Phone, MapPin, Send, MessageCircle, Sparkles, Globe, Heart } from 'lucide-react';

const ContactPage: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      const { clientX, clientY } = e;
      const moveX = (clientX - window.innerWidth / 2) / 40;
      const moveY = (clientY - window.innerHeight / 2) / 40;
      setMousePos({ x: moveX, y: moveY });
    };
    window.addEventListener('mousemove', handleMouseMove);

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let particles: { x: number; y: number; size: number; speedX: number; speedY: number; opacity: number }[] = [];
    const particleCount = 40;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      particles = Array.from({ length: particleCount }, () => ({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size: Math.random() * 2 + 1,
        speedX: (Math.random() - 0.5) * 0.3,
        speedY: (Math.random() - 0.5) * 0.3,
        opacity: Math.random() * 0.5 + 0.1,
      }));
    };

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particles.forEach((p) => {
        p.x += p.speedX;
        p.y += p.speedY;
        if (p.x > canvas.width) p.x = 0;
        if (p.x < 0) p.x = canvas.width;
        if (p.y > canvas.height) p.y = 0;
        if (p.y < 0) p.y = canvas.height;
        ctx.fillStyle = `rgba(168, 85, 247, ${p.opacity})`;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      });
      animationFrameId = requestAnimationFrame(animate);
    };

    window.addEventListener('resize', resize);
    resize();
    animate();
    return () => {
      window.removeEventListener('resize', resize);
      window.removeEventListener('mousemove', handleMouseMove);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <div className="relative w-full h-[55vh] min-h-[500px] flex flex-col items-center justify-center overflow-hidden bg-[#f8f5ff]">
        <div className="absolute inset-0 z-0">
          <canvas ref={canvasRef} className="absolute inset-0 z-0 pointer-events-none" />
          <div className="absolute inset-0 opacity-15 pointer-events-none" 
               style={{ backgroundImage: `repeating-linear-gradient(90deg, transparent, transparent 45px, rgba(255, 255, 255, 0.4) 50px, transparent 55px, transparent 100px)`, filter: 'blur(30px)' }} />
        </div>

        <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 flex flex-col items-center text-center transition-transform duration-300 ease-out"
             style={{ transform: `translate(${mousePos.x * 0.1}px, ${mousePos.y * 0.1}px)` }}>
          
          <div className="flex items-center gap-4 mb-6 opacity-60 animate-reveal">
            <div className="h-[1.5px] w-12 bg-purple-400"></div>
            <span className="text-[10px] sm:text-[11px] font-black uppercase tracking-[0.4em] text-gray-800">Contact us</span>
            <div className="h-[1.5px] w-12 bg-purple-400"></div>
          </div>

          <div className="relative flex flex-col items-center mb-8 sm:mb-10 group cursor-default w-full">
            <h1 className="flex flex-wrap items-center justify-center gap-x-2 sm:gap-x-4 text-4xl sm:text-6xl md:text-8xl lg:text-[10rem] font-black text-[#1a1c2d] tracking-tighter leading-none animate-reveal transition-transform duration-500 overflow-visible"
                style={{ transform: `translate(${mousePos.x * 0.4}px, ${mousePos.y * 0.4}px)` }}>
              <span className="uppercase">CONTACT</span>
              <span className="inline-block px-2 sm:px-4 italic text-transparent bg-clip-text bg-gradient-to-r from-[#9b4dff] via-[#8a3ffc] to-[#ff2d85] drop-shadow-sm select-none">
                US
              </span>
            </h1>
          </div>

          <div className="max-w-2xl animate-reveal stagger-2 mt-4" style={{ transform: `translate(${mousePos.x * 0.2}px, ${mousePos.y * 0.2}px)` }}>
            <p className="text-lg sm:text-xl md:text-2xl font-light italic text-gray-700 tracking-tight leading-tight px-4">
              We're here to walk by your side, every step of the way.
            </p>
          </div>
        </div>

        {/* Curved Bottom Mask */}
        <div 
          className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[160%] h-[150px] sm:h-[200px] bg-white z-20"
          style={{ borderRadius: '100% 100% 0 0', transform: 'translateX(-50%) translateY(50%)' }}
        />
      </div>

      {/* Main Content Area */}
      <section className="py-24 px-6 relative z-30">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-16 lg:gap-24">
          
          {/* Left Column: Contact Info */}
          <div className="lg:col-span-5 space-y-12 animate-reveal">
            <div>
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-50 border border-purple-100 mb-6">
                <Sparkles size={14} className="text-purple-500" />
                <span className="text-[10px] uppercase tracking-widest text-purple-600 font-bold">Connections</span>
              </div>
              <h3 className="text-3xl sm:text-4xl md:text-5xl font-black text-gray-900 mb-8 tracking-tighter leading-none uppercase">
                Available to <br /><span className="text-[#8a3ffc]">Support You</span>
              </h3>
              <p className="text-gray-500 text-lg leading-relaxed font-medium">
                Our team of specialists is ready to provide guidance and answer any questions about our DSA English programs.
              </p>
            </div>

            <div className="space-y-6">
              {/* Phone */}
              <div className="flex items-center gap-6 p-6 sm:p-8 bg-white rounded-[2.5rem] border border-gray-100 shadow-sm hover:shadow-xl transition-all duration-500">
                <div className="w-12 h-12 sm:w-14 sm:h-14 bg-purple-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-purple-200 shrink-0">
                  <Phone size={24} />
                </div>
                <div>
                  <p className="text-[9px] sm:text-[10px] font-black uppercase tracking-widest text-gray-400 mb-1">Call Us</p>
                  <a href="tel:+393518459607" className="text-lg sm:text-xl font-black text-gray-900 hover:text-purple-600 transition-colors tracking-tight">+39 351 8459607</a>
                </div>
              </div>

              {/* Emails */}
              <div className="flex items-center gap-6 p-6 sm:p-8 bg-white rounded-[2.5rem] border border-gray-100 shadow-sm hover:shadow-xl transition-all duration-500">
                <div className="w-12 h-12 sm:w-14 sm:h-14 bg-pink-500 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-pink-200 shrink-0">
                  <Mail size={24} />
                </div>
                <div className="overflow-hidden">
                  <p className="text-[9px] sm:text-[10px] font-black uppercase tracking-widest text-gray-400 mb-1">Email Us</p>
                  <p className="text-base sm:text-lg font-black text-gray-900 leading-tight mb-1 truncate">dsa.smart.start@gmail.com</p>
                  <p className="text-sm sm:text-lg font-bold text-gray-500 leading-tight truncate">smartstart.dsa@gmail.com</p>
                </div>
              </div>

              {/* Address */}
              <div className="flex items-center gap-6 p-6 sm:p-8 bg-white rounded-[2.5rem] border border-gray-100 shadow-sm hover:shadow-xl transition-all duration-500">
                <div className="w-12 h-12 sm:w-14 sm:h-14 bg-blue-500 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-blue-200 shrink-0">
                  <MapPin size={24} />
                </div>
                <div>
                  <p className="text-[9px] sm:text-[10px] font-black uppercase tracking-widest text-gray-400 mb-1">Visit Us</p>
                  <p className="text-base sm:text-lg font-black text-gray-900">Viale Bonaria, 90</p>
                  <p className="text-sm sm:text-lg font-bold text-gray-500 italic">09125 Cagliari, Italy</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Form */}
          <div className="lg:col-span-7 animate-reveal stagger-1">
            <div className="bg-white p-6 sm:p-10 md:p-14 rounded-[3rem] sm:rounded-[3.5rem] border border-gray-100 shadow-2xl shadow-purple-500/5 relative overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-purple-50 rounded-full blur-[100px] -translate-y-1/2 translate-x-1/2 opacity-50"></div>
              
              <div className="relative z-10">
                <div className="flex items-center gap-4 mb-8 sm:mb-10">
                  <div className="w-10 h-10 sm:w-12 sm:h-12 bg-gray-900 rounded-2xl flex items-center justify-center text-white shadow-lg">
                    <MessageCircle size={20} sm:size={24} />
                  </div>
                  <h4 className="text-2xl sm:text-3xl font-black text-gray-900 tracking-tight uppercase">Get In Touch!!</h4>
                </div>

                <form className="grid grid-cols-1 md:grid-cols-2 gap-4 sm:gap-6 md:gap-8" onSubmit={(e) => e.preventDefault()}>
                  <div className="flex flex-col gap-2">
                    <label className="text-[9px] sm:text-[10px] font-black uppercase tracking-widest text-gray-400 ml-4">First Name</label>
                    <input 
                      type="text" 
                      placeholder="First Name"
                      className="w-full px-6 sm:px-8 py-4 sm:py-5 rounded-[2rem] bg-gray-50 border border-transparent focus:bg-white focus:border-[#8a3ffc] focus:outline-none transition-all font-bold text-gray-900"
                    />
                  </div>
                  <div className="flex flex-col gap-2">
                    <label className="text-[9px] sm:text-[10px] font-black uppercase tracking-widest text-gray-400 ml-4">Last Name</label>
                    <input 
                      type="text" 
                      placeholder="Last Name"
                      className="w-full px-6 sm:px-8 py-4 sm:py-5 rounded-[2rem] bg-gray-50 border border-transparent focus:bg-white focus:border-[#8a3ffc] focus:outline-none transition-all font-bold text-gray-900"
                    />
                  </div>
                  <div className="flex flex-col gap-2 md:col-span-2">
                    <label className="text-[9px] sm:text-[10px] font-black uppercase tracking-widest text-gray-400 ml-4">Email *</label>
                    <input 
                      type="email" 
                      placeholder="Email address"
                      required
                      className="w-full px-6 sm:px-8 py-4 sm:py-5 rounded-[2rem] bg-gray-50 border border-transparent focus:bg-white focus:border-[#8a3ffc] focus:outline-none transition-all font-bold text-gray-900"
                    />
                  </div>
                  <div className="flex flex-col gap-2">
                    <label className="text-[9px] sm:text-[10px] font-black uppercase tracking-widest text-gray-400 ml-4">Mobile</label>
                    <input 
                      type="tel" 
                      placeholder="Mobile number"
                      className="w-full px-6 sm:px-8 py-4 sm:py-5 rounded-[2rem] bg-gray-50 border border-transparent focus:bg-white focus:border-[#8a3ffc] focus:outline-none transition-all font-bold text-gray-900"
                    />
                  </div>
                  <div className="flex flex-col gap-2">
                    <label className="text-[9px] sm:text-[10px] font-black uppercase tracking-widest text-gray-400 ml-4">Subject</label>
                    <input 
                      type="text" 
                      placeholder="Subject"
                      className="w-full px-6 sm:px-8 py-4 sm:py-5 rounded-[2rem] bg-gray-50 border border-transparent focus:bg-white focus:border-[#8a3ffc] focus:outline-none transition-all font-bold text-gray-900"
                    />
                  </div>
                  <div className="flex flex-col gap-2 md:col-span-2">
                    <label className="text-[9px] sm:text-[10px] font-black uppercase tracking-widest text-gray-400 ml-4">Message</label>
                    <textarea 
                      rows={4}
                      placeholder="Your message"
                      className="w-full px-6 sm:px-8 py-4 sm:py-6 rounded-[2rem] sm:rounded-[2.5rem] bg-gray-50 border border-transparent focus:bg-white focus:border-[#8a3ffc] focus:outline-none transition-all font-bold text-gray-900 resize-none"
                    ></textarea>
                  </div>
                  <div className="md:col-span-2 mt-4">
                    <button 
                      type="submit"
                      className="group w-full flex items-center justify-center gap-4 bg-[#8a3ffc] text-white py-5 sm:py-6 rounded-[2.5rem] font-black uppercase tracking-[0.2em] shadow-2xl hover:bg-[#7a2fec] active:scale-95 transition-all text-xs sm:text-base"
                    >
                      SEND MESSAGE
                      <Send size={18} />
                    </button>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section className="pb-32 px-6">
        <div className="max-w-7xl mx-auto">
          <div className="relative overflow-hidden rounded-[3rem] sm:rounded-[4rem] h-[400px] sm:h-[500px] shadow-2xl border-4 sm:border-8 border-white bg-gray-50">
             <iframe 
                title="Google Maps Location"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3077.584347230492!2d9.123284076391483!3d39.21448657165736!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x12e7343e59005471%3A0x67347a460b61030b!2sViale%20Bonaria%2C%2090%2C%2009125%20Cagliari%20CA%2C%20Italy!5e0!3m2!1sen!2sus!4v1714574923485!5m2!1sen!2sus"
                width="100%" 
                height="100%" 
                style={{ border: 0 }} 
                allowFullScreen={true} 
                loading="lazy" 
                referrerPolicy="no-referrer-when-downgrade"
             ></iframe>
          </div>
        </div>
      </section>
    </div>
  );
};

export default ContactPage;
