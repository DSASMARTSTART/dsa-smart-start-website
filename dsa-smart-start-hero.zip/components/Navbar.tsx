
import React, { useState, useEffect } from 'react';
import { Menu, X, ChevronRight, ShoppingCart, User, LogOut, Layout } from 'lucide-react';

interface NavbarProps {
  onNavigate: (path: string) => void;
  currentPath: string;
  cartCount: number;
  isLoggedIn?: boolean;
  user?: {name: string, email: string} | null;
  onLogout?: () => void;
}

const Navbar: React.FC<NavbarProps> = ({ onNavigate, currentPath, cartCount, isLoggedIn, user, onLogout }) => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [profileOpen, setProfileOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = isLoggedIn 
    ? [
        { name: 'Dashboard', path: 'dashboard' },
        { name: 'Browse Courses', path: 'courses' },
        { name: 'FAQ', path: 'faq' },
        { name: 'Contacts', path: 'contact' },
      ]
    : [
        { name: 'Home', path: 'home' },
        { name: 'Who We Are', path: 'who-we-are' },
        { name: 'Courses', path: 'courses' },
        { name: 'FAQ', path: 'faq' },
        { name: 'Contacts', path: 'contact' },
        { name: 'Login/Register', path: 'login' },
      ];

  const handleLinkClick = (path: string) => {
    onNavigate(path);
    setMobileMenuOpen(false);
  };

  return (
    <nav className={`fixed top-0 left-0 w-full z-[100] transition-all duration-500 ${isScrolled ? 'py-4' : 'py-6'}`}>
      <div className="max-w-7xl mx-auto px-4 md:px-6">
        <div className={`flex items-center justify-between bg-white/70 backdrop-blur-xl border border-white/20 px-4 md:px-8 py-3 rounded-full transition-shadow duration-500 ${isScrolled ? 'shadow-xl shadow-purple-500/5' : ''}`}>
          
          <button onClick={() => handleLinkClick(isLoggedIn ? 'dashboard' : 'home')} className="flex items-center gap-3 shrink-0">
            <div className="w-9 h-9 md:w-10 md:h-10 bg-[#8a3ffc] rounded-xl rotate-12 flex items-center justify-center shadow-lg shadow-purple-200">
              <span className="text-white font-black text-sm -rotate-12">S</span>
            </div>
            <span className="hidden sm:inline-block text-lg font-black tracking-tighter text-gray-900 whitespace-nowrap">
              DSA <span className="text-[#8a3ffc]">SMART START</span>
            </span>
          </button>

          <div className="hidden lg:flex items-center gap-6 xl:gap-8 mx-4">
            {navLinks.map((link) => (
              <button 
                key={link.name} 
                onClick={() => handleLinkClick(link.path)}
                className={`text-[10px] xl:text-[11px] font-black transition-colors tracking-widest whitespace-nowrap uppercase ${currentPath === link.path ? 'text-[#8a3ffc]' : 'text-gray-700 hover:text-[#8a3ffc]'}`}
              >
                {link.name}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-3 md:gap-4 shrink-0">
            <button 
              onClick={() => handleLinkClick('checkout')}
              className="relative p-2.5 rounded-full bg-gray-50 text-gray-600 hover:bg-purple-50 hover:text-purple-600 transition-all border border-gray-100"
            >
              <ShoppingCart size={18} />
              {cartCount > 0 && (
                <span className="absolute -top-1 -right-1 w-5 h-5 bg-pink-500 text-white text-[10px] font-black rounded-full flex items-center justify-center shadow-lg border-2 border-white animate-bounce">
                  {cartCount}
                </span>
              )}
            </button>

            {isLoggedIn ? (
              <div className="relative">
                <button 
                  onClick={() => setProfileOpen(!profileOpen)}
                  className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-indigo-600 flex items-center justify-center text-white border-2 border-white shadow-md hover:scale-105 transition-transform"
                >
                  <User size={18} />
                </button>
                {profileOpen && (
                  <div className="absolute top-full right-0 mt-4 w-48 bg-white rounded-2xl shadow-2xl border border-gray-100 p-2 overflow-hidden animate-reveal">
                    <button 
                      onClick={() => { handleLinkClick('dashboard'); setProfileOpen(false); }}
                      className="w-full flex items-center gap-3 px-4 py-3 text-[11px] font-black uppercase text-gray-700 hover:bg-purple-50 hover:text-purple-600 rounded-xl transition-all"
                    >
                      <Layout size={14} />
                      Dashboard
                    </button>
                    <button 
                      onClick={() => { onLogout?.(); setProfileOpen(false); }}
                      className="w-full flex items-center gap-3 px-4 py-3 text-[11px] font-black uppercase text-pink-600 hover:bg-pink-50 rounded-xl transition-all"
                    >
                      <LogOut size={14} />
                      Logout
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="hidden md:block">
                <button 
                  onClick={() => handleLinkClick('contact')}
                  className="flex items-center gap-2 bg-[#8a3ffc] text-white px-6 xl:px-8 py-3 rounded-full text-[10px] font-black uppercase tracking-widest hover:bg-[#7a2fec] shadow-lg shadow-purple-100 transition-all active:scale-95 whitespace-nowrap"
                >
                  BOOK NOW
                  <ChevronRight size={14} />
                </button>
              </div>
            )}

            {!mobileMenuOpen && (
              <button 
                className="lg:hidden p-2 text-gray-900"
                onClick={() => setMobileMenuOpen(true)}
              >
                <Menu size={24} />
              </button>
            )}
          </div>
        </div>
      </div>

      <div className={`fixed inset-0 bg-white/98 backdrop-blur-2xl z-[110] transition-all duration-500 lg:hidden ${mobileMenuOpen ? 'opacity-100 translate-y-0' : 'opacity-0 -translate-y-full pointer-events-none'}`}>
        <button 
          onClick={() => setMobileMenuOpen(false)}
          className="absolute top-8 right-8 p-3 bg-gray-50 text-gray-900 rounded-full"
        >
          <X size={28} strokeWidth={2.5} />
        </button>

        <div className="flex flex-col items-center justify-center h-full gap-8 p-6 text-center">
          {navLinks.map((link, idx) => (
            <button 
              key={link.name} 
              onClick={() => handleLinkClick(link.path)}
              className="text-2xl font-black transition-all uppercase tracking-tight text-gray-900 hover:text-[#8a3ffc]"
            >
              {link.name}
            </button>
          ))}
          {isLoggedIn && onLogout && (
             <button onClick={() => { onLogout(); setMobileMenuOpen(false); }} className="text-2xl font-black text-pink-600 uppercase tracking-tight">
               Logout
             </button>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
