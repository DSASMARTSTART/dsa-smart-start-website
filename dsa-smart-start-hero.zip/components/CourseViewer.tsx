
import React, { useState } from 'react';
import { ArrowLeft, CheckCircle2, Circle, ChevronRight, PlayCircle, BookOpen, Clock, FileText, ChevronDown, ChevronUp, ClipboardCheck } from 'lucide-react';

interface Lesson {
  id: string;
  title: string;
  duration: string;
  type: 'video' | 'quiz' | 'reading';
}

interface Homework {
  id: string;
  title: string;
}

interface Module {
  id: string;
  title: string;
  lessons: Lesson[];
  homework: Homework[];
}

interface CourseViewerProps {
  courseId: string;
  progress: Record<string, boolean>;
  onToggleProgress: (courseId: string, itemKey: string) => void;
  onBack: () => void;
}

const CourseViewer: React.FC<CourseViewerProps> = ({ courseId, progress, onToggleProgress, onBack }) => {
  // Synchronized course data with syllabus (15 units per course)
  const COURSE_DATA: Record<string, { name: string, modules: Module[] }> = {
    "a1": {
      name: "DSA SMART START A1",
      modules: [
        {
          id: "m1",
          title: "Foundations of Being",
          lessons: [
            { id: "l1", title: "Unit 1: Subject Pronouns", duration: "12m", type: 'video' },
            { id: "l2", title: "Unit 2: Verb TO BE", duration: "15m", type: 'video' },
            { id: "l3", title: "Unit 3: Regular Plural Nouns", duration: "10m", type: 'reading' },
            { id: "l4", title: "Unit 4: Irregular Plural Nouns", duration: "10m", type: 'reading' },
            { id: "l5", title: "Unit 5: Past simple of Verb TO BE", duration: "14m", type: 'video' },
          ],
          homework: [
            { id: "h1", title: "Pronouns Memory Map" },
            { id: "h2", title: "Verb Be Visual Quiz" }
          ]
        },
        {
          id: "m2",
          title: "Daily Expression",
          lessons: [
            { id: "l6", title: "Unit 6: Saxon Genitive", duration: "18m", type: 'video' },
            { id: "l7", title: "Unit 7: Demonstratives", duration: "14m", type: 'video' },
            { id: "l8", title: "Unit 8: Present Simple Intro", duration: "20m", type: 'video' },
            { id: "l9", title: "Unit 9: Frequency Adverbs", duration: "12m", type: 'reading' },
            { id: "l10", title: "Unit 10: Past Simple Verbs", duration: "25m", type: 'video' },
          ],
          homework: [
            { id: "h3", title: "Daily Routine Designer" }
          ]
        },
        {
          id: "m3",
          title: "Advanced Foundations",
          lessons: [
            { id: "l11", title: "Unit 11: Imperative Forms", duration: "10m", type: 'reading' },
            { id: "l12", title: "Unit 12: Modal Verb WILL", duration: "15m", type: 'video' },
            { id: "l13", title: "Unit 13: Have vs Have Got", duration: "12m", type: 'video' },
            { id: "l14", title: "Unit 14: Time Prepositions", duration: "18m", type: 'reading' },
            { id: "l15", title: "Unit 15: Present Continuous", duration: "22m", type: 'video' },
          ],
          homework: []
        }
      ]
    },
    "a2": {
      name: "DSA SMART START A2",
      modules: [
        {
          id: "m1",
          title: "Narrative & Flow",
          lessons: [
            { id: "l1", title: "Unit 1: Present Simple vs Continuous", duration: "15m", type: 'video' },
            { id: "l2", title: "Unit 2: Past Continuous Intro", duration: "12m", type: 'video' },
            { id: "l3", title: "Unit 3: Continuous vs Simple", duration: "18m", type: 'video' },
            { id: "l4", title: "Unit 4: Adverbs of Manner", duration: "10m", type: 'reading' },
            { id: "l5", title: "Unit 5: Articles A/An/The", duration: "12m", type: 'video' },
          ],
          homework: [
            { id: "h1", title: "Timeline Mapping" }
          ]
        },
        {
          id: "m2",
          title: "Quantifiers & Modals",
          lessons: [
            { id: "l6", title: "Unit 6: Countable Nouns", duration: "15m", type: 'video' },
            { id: "l7", title: "Unit 7: Uncountable Nouns", duration: "12m", type: 'video' },
            { id: "l8", title: "Unit 8: Comparatives", duration: "18m", type: 'video' },
            { id: "l9", title: "Unit 9: Superlatives", duration: "10m", type: 'reading' },
            { id: "l10", title: "Unit 10: Modals MUST/SHOULD", duration: "12m", type: 'video' },
          ],
          homework: []
        },
        {
          id: "m3",
          title: "Future & Perfect",
          lessons: [
            { id: "l11", title: "Unit 11: Future GOING TO", duration: "15m", type: 'video' },
            { id: "l12", title: "Unit 12: Future WILL", duration: "12m", type: 'video' },
            { id: "l13", title: "Unit 13: Present Perfect", duration: "18m", type: 'video' },
            { id: "l14", title: "Unit 14: For vs Since", duration: "10m", type: 'reading' },
            { id: "l15", title: "Unit 15: Conditionals Intro", duration: "12m", type: 'video' },
          ],
          homework: []
        }
      ]
    }
  };

  const course = COURSE_DATA[courseId] || COURSE_DATA["a1"];
  const [activeModuleId, setActiveModuleId] = useState(course.modules[0].id);
  const [selectedItemId, setSelectedItemId] = useState(course.modules[0].lessons[0].id);

  const currentModuleIndex = course.modules.findIndex(m => m.id === activeModuleId);
  const currentModule = course.modules[currentModuleIndex] || course.modules[0];
  
  const selectedLesson = currentModule.lessons.find(l => l.id === selectedItemId);
  const selectedHomework = currentModule.homework.find(h => h.id === selectedItemId);
  const selectedItem = selectedLesson || selectedHomework || currentModule.lessons[0];

  const isCompleted = (id: string) => !!progress[`${courseId}_${id}`];
  
  const calculateCourseProgress = () => {
    let total = 0;
    let done = 0;
    course.modules.forEach(m => {
      m.lessons.forEach(l => { total++; if (isCompleted(l.id)) done++; });
      m.homework.forEach(h => { total++; if (isCompleted(h.id)) done++; });
    });
    return Math.round((done / total) * 100);
  };

  const handleNext = () => {
    const currentItems = [...currentModule.lessons, ...currentModule.homework];
    const currentIndex = currentItems.findIndex(item => item.id === selectedItemId);

    if (currentIndex < currentItems.length - 1) {
      setSelectedItemId(currentItems[currentIndex + 1].id);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else if (currentModuleIndex < course.modules.length - 1) {
      const nextModule = course.modules[currentModuleIndex + 1];
      setActiveModuleId(nextModule.id);
      setSelectedItemId(nextModule.lessons[0].id);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      onBack();
    }
  };

  const getNextLabel = () => {
    const currentItems = [...currentModule.lessons, ...currentModule.homework];
    const currentIndex = currentItems.findIndex(item => item.id === selectedItemId);

    if (currentIndex < currentItems.length - 1) {
      return `Next: ${currentItems[currentIndex + 1].title}`;
    } else if (currentModuleIndex < course.modules.length - 1) {
      return `Next Module: ${course.modules[currentModuleIndex + 1].title}`;
    }
    return "Course Complete! Return to Dashboard";
  };

  return (
    <div className="bg-[#f8f9fb] min-h-screen pt-24">
      {/* Top Header */}
      <div className="bg-white border-b border-gray-100 py-6 px-8 flex flex-col md:flex-row items-center justify-between gap-6 fixed top-24 left-0 right-0 z-40">
        <div className="flex items-center gap-6">
          <button onClick={onBack} className="p-2 hover:bg-gray-50 rounded-full text-gray-400 hover:text-purple-600 transition-all">
            <ArrowLeft size={20} />
          </button>
          <div className="h-10 w-px bg-gray-100"></div>
          <div>
            <span className="text-[10px] font-black uppercase tracking-widest text-purple-500 mb-1 block">Classroom Environment</span>
            <h1 className="text-xl font-black text-gray-900 tracking-tight uppercase">{course.name}</h1>
          </div>
        </div>

        <div className="flex items-center gap-8 w-full md:w-auto">
          <div className="flex-grow md:flex-initial min-w-[150px]">
             <div className="flex justify-between items-end mb-1">
                <span className="text-[9px] font-black uppercase tracking-widest text-gray-400">Course Progress</span>
                <span className="text-xs font-black text-gray-900">{calculateCourseProgress()}%</span>
             </div>
             <div className="h-2 w-full bg-gray-100 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-purple-600 transition-all duration-500"
                  style={{ width: `${calculateCourseProgress()}%` }}
                ></div>
             </div>
          </div>
          <button 
            onClick={handleNext}
            className="flex items-center gap-2 px-6 py-2.5 bg-[#8a3ffc] text-white rounded-xl font-black text-[10px] uppercase tracking-widest shadow-lg shadow-purple-100 hover:scale-105 active:scale-95 transition-all"
          >
            Continue Next
            <ChevronRight size={14} />
          </button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-0 lg:gap-8 pt-32 lg:pt-24 min-h-[calc(100vh-100px)]">
        
        {/* Sidebar */}
        <div className="lg:col-span-4 bg-white border-r border-gray-100 h-full lg:sticky lg:top-[184px] lg:h-[calc(100vh-184px)] overflow-y-auto custom-scrollbar p-6">
          <div className="space-y-6">
            {course.modules.map((module) => (
              <div key={module.id} className="space-y-3">
                <button 
                  onClick={() => setActiveModuleId(module.id)}
                  className={`w-full text-left p-4 rounded-2xl flex items-center justify-between transition-all ${activeModuleId === module.id ? 'bg-purple-50 border border-purple-100' : 'hover:bg-gray-50'}`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-lg flex items-center justify-center font-black text-[10px] ${activeModuleId === module.id ? 'bg-purple-600 text-white' : 'bg-gray-100 text-gray-400'}`}>
                      {module.id.toUpperCase()}
                    </div>
                    <h4 className={`text-sm font-black uppercase tracking-tight ${activeModuleId === module.id ? 'text-purple-900' : 'text-gray-900'}`}>
                      {module.title}
                    </h4>
                  </div>
                  {activeModuleId === module.id ? <ChevronUp size={16} /> : <ChevronDown size={16} />}
                </button>

                {activeModuleId === module.id && (
                  <div className="pl-4 space-y-2 animate-reveal">
                    {module.lessons.map(lesson => (
                      <button 
                        key={lesson.id}
                        onClick={() => setSelectedItemId(lesson.id)}
                        className={`w-full flex items-center justify-between p-3 rounded-xl text-left transition-all ${selectedItemId === lesson.id ? 'bg-gray-50 shadow-sm ring-1 ring-purple-100' : 'hover:bg-gray-50'}`}
                      >
                        <div className="flex items-center gap-3">
                          {isCompleted(lesson.id) ? (
                            <CheckCircle2 size={16} className="text-green-500 shrink-0" />
                          ) : (
                            <Circle size={16} className="text-gray-300 shrink-0" />
                          )}
                          <div className="overflow-hidden">
                            <p className={`text-xs font-bold leading-tight truncate ${selectedItemId === lesson.id ? 'text-purple-600' : 'text-gray-700'}`}>
                              {lesson.title}
                            </p>
                            <span className="text-[9px] font-bold text-gray-400 uppercase tracking-widest">{lesson.duration} • {lesson.type}</span>
                          </div>
                        </div>
                        {lesson.type === 'video' && <PlayCircle size={14} className="text-gray-400 shrink-0" />}
                      </button>
                    ))}

                    {module.homework.length > 0 && (
                      <div className="pt-2 border-t border-gray-50 mt-2">
                        <p className="text-[9px] font-black uppercase tracking-[0.2em] text-gray-400 mb-2 pl-3">Assignments</p>
                        {module.homework.map(h => (
                          <button 
                            key={h.id}
                            onClick={() => setSelectedItemId(h.id)}
                            className={`w-full flex items-center gap-3 p-3 rounded-xl text-left transition-all ${selectedItemId === h.id ? 'bg-gray-50 shadow-sm ring-1 ring-purple-100' : 'hover:bg-gray-50'}`}
                          >
                            {isCompleted(h.id) ? (
                               <CheckCircle2 size={16} className="text-green-500 shrink-0" />
                             ) : (
                               <FileText size={16} className="text-gray-300 shrink-0" />
                             )}
                            <p className={`text-xs font-bold truncate ${selectedItemId === h.id ? 'text-purple-600' : 'text-gray-600'}`}>{h.title}</p>
                          </button>
                        ))}
                      </div>
                    )}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Main Viewer Area */}
        <div className="lg:col-span-8 p-6 md:p-12 overflow-y-auto h-full animate-reveal">
          <div className="flex items-center gap-2 mb-8">
            <span className="text-[9px] font-bold text-gray-400 uppercase tracking-widest">Learning Center</span>
            <ChevronRight size={10} className="text-gray-300" />
            <span className="text-[9px] font-bold text-gray-400 uppercase tracking-widest">{course.name}</span>
            <ChevronRight size={10} className="text-gray-300" />
            <span className="text-[9px] font-bold text-purple-600 uppercase tracking-widest">{selectedItem.title}</span>
          </div>

          <div className="bg-white rounded-[3rem] border border-gray-100 shadow-xl shadow-purple-500/5 overflow-hidden mb-12">
            {selectedLesson ? (
              selectedLesson.type === 'video' ? (
                <div className="aspect-video bg-[#0f172a] flex items-center justify-center relative group">
                  <PlayCircle size={80} className="text-white/20 group-hover:text-purple-500/80 transition-all group-hover:scale-110 cursor-pointer" />
                  <div className="absolute bottom-6 left-6 text-white/40 text-[10px] font-black uppercase tracking-widest">DSA SMART START PLAYER</div>
                </div>
              ) : (
                <div className="p-12 md:p-20 text-center">
                  <div className="w-20 h-20 bg-purple-50 rounded-3xl flex items-center justify-center text-purple-600 mx-auto mb-8 border border-purple-100">
                    <BookOpen size={40} />
                  </div>
                  <h3 className="text-3xl font-black text-gray-900 mb-6 uppercase tracking-tight">Reading Resource</h3>
                  <p className="text-gray-500 text-lg max-w-xl mx-auto leading-relaxed">
                    Access visual materials. High-contrast viewing mode recommended.
                  </p>
                </div>
              )
            ) : (
              <div className="p-12 md:p-20 text-center bg-gray-50/50">
                <div className="w-20 h-20 bg-indigo-50 rounded-3xl flex items-center justify-center text-indigo-600 mx-auto mb-8 border border-indigo-100 shadow-sm">
                  <ClipboardCheck size={40} />
                </div>
                <h3 className="text-3xl font-black text-gray-900 mb-6 uppercase tracking-tight">Practice Milestone</h3>
                <p className="text-gray-500 text-lg max-w-xl mx-auto leading-relaxed">
                  Record your practice results for this assignment.
                </p>
              </div>
            )}

            <div className="p-10 flex flex-col md:flex-row items-center justify-between gap-8 border-t border-gray-50">
               <div>
                  <h2 className="text-2xl font-black text-gray-900 tracking-tight uppercase mb-2">{selectedItem.title}</h2>
                  <p className="text-gray-500 font-medium">{selectedLesson ? `Part of ${currentModule.title}` : 'Independent Assignment'}</p>
               </div>
               <button 
                 onClick={() => onToggleProgress(courseId, selectedItem.id)}
                 className={`flex items-center gap-3 px-10 py-5 rounded-2xl font-black text-[10px] uppercase tracking-widest shadow-xl transition-all ${isCompleted(selectedItem.id) ? 'bg-green-500 text-white shadow-green-100' : 'bg-gray-900 text-white hover:bg-purple-600 shadow-gray-100'}`}
               >
                 {isCompleted(selectedItem.id) ? (
                   <><CheckCircle2 size={18} /> Completed</>
                 ) : (
                   'Mark as Completed'
                 )}
               </button>
            </div>
          </div>

          <button 
            onClick={handleNext}
            className="w-full bg-[#f3e8ff]/50 rounded-[3rem] border border-purple-100 p-10 flex flex-col md:flex-row items-center justify-between gap-8 group transition-all hover:bg-purple-100/50"
          >
            <div className="flex items-center gap-6">
              <div className="w-16 h-16 bg-white rounded-2xl flex items-center justify-center text-purple-600 shadow-sm border border-purple-50 group-hover:scale-110 transition-transform">
                <Clock size={28} />
              </div>
              <div className="text-left">
                <h4 className="text-xl font-black text-gray-900 tracking-tight uppercase mb-1">Coming Up Next</h4>
                <p className="text-gray-500 font-medium">{getNextLabel()}</p>
              </div>
            </div>
            <div className="flex items-center gap-3 text-[10px] font-black uppercase tracking-widest text-purple-600 group-hover:gap-6 transition-all">
              GO TO NEXT
              <ChevronRight size={18} />
            </div>
          </button>
        </div>
      </div>
      
      <style dangerouslySetInnerHTML={{ __html: `
        .custom-scrollbar::-webkit-scrollbar { width: 4px; }
        .custom-scrollbar::-webkit-scrollbar-track { background: #f8f9fb; }
        .custom-scrollbar::-webkit-scrollbar-thumb { background: #e5e7eb; border-radius: 10px; }
      `}} />
    </div>
  );
};

export default CourseViewer;
