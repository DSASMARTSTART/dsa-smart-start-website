
import React from 'react';
import { Star, Zap, Award, BookOpen, Music, Play, Layers, Compass, ChevronRight } from 'lucide-react';

const CoursesSection: React.FC = () => {
  const adultCourses = [
    { name: "A1 LEVEL", level: "Beginner", icon: <Layers size={22} />, color: "from-blue-500 to-indigo-600", desc: "Foundation strategies for complete beginners with dyslexia." },
    { name: "A2 LEVEL", level: "Elementary", icon: <Compass size={22} />, color: "from-indigo-500 to-purple-600", desc: "Developing confidence in daily communication and basic structures." },
    { name: "B1 LEVEL", level: "Intermediate", icon: <Zap size={22} />, color: "from-purple-600 to-pink-600", desc: "Independent usage with specialized DSA tools for advanced reasoning." },
  ];

  const kidsCourses = [
    { name: "BASIC", level: "Early Years", icon: <Music size={22} />, color: "from-pink-500 to-rose-500", desc: "Introduction through songs, visuals, and sensory exploration." },
    { name: "MEDIUM", level: "Primary", icon: <Play size={22} />, color: "from-rose-500 to-orange-500", desc: "Interactive storytelling and vocabulary games for active focus." },
    { name: "ADVANCED", level: "Pre-Teen", icon: <Award size={22} />, color: "from-orange-500 to-amber-500", desc: "Preparing for school success with advanced visual mnemonics." },
  ];

  return (
    <section className="py-32 bg-slate-50 relative overflow-hidden">
      {/* Decorative Orbs */}
      <div className="absolute top-0 left-0 w-96 h-96 bg-purple-100 rounded-full blur-[120px] -translate-x-1/2 -translate-y-1/2 opacity-40"></div>
      <div className="absolute bottom-0 right-0 w-96 h-96 bg-pink-100 rounded-full blur-[120px] translate-x-1/2 translate-y-1/2 opacity-40"></div>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        <div className="flex flex-col lg:flex-row justify-between items-end mb-24 gap-8">
          <div className="max-w-2xl">
            <span className="text-[10px] font-black text-purple-600 uppercase tracking-[0.4em] mb-4 block">Our Curriculum</span>
            <h3 className="text-4xl md:text-6xl font-black text-gray-900 leading-[1.1] tracking-tighter">
              Tailored Programs for <br /> Every <span className="text-transparent bg-clip-text bg-gradient-to-r from-purple-600 to-pink-600">Learning Stage</span>
            </h3>
          </div>
          <p className="text-gray-500 lg:max-w-sm text-lg font-medium leading-relaxed">
            Meticulously structured pathways to accommodate neurodiversity, ensuring progress without frustration.
          </p>
        </div>

        {/* Adults & Teens Section */}
        <div className="mb-32">
          <div className="flex items-center gap-6 mb-12">
            <h4 className="text-sm font-black text-gray-400 uppercase tracking-widest whitespace-nowrap">Adults & Teens</h4>
            <div className="h-[1px] flex-grow bg-gradient-to-r from-gray-200 to-transparent"></div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {adultCourses.map((course, i) => (
              <div key={i} className="group relative bg-white rounded-[2rem] p-10 border border-gray-100 shadow-sm hover:shadow-2xl hover:shadow-purple-200/20 transition-all duration-500">
                <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${course.color} text-white flex items-center justify-center mb-8 shadow-lg shadow-purple-200 transform group-hover:-translate-y-2 transition-transform duration-500`}>
                  {course.icon}
                </div>
                <div className="mb-6">
                  <span className="text-[10px] font-black text-purple-500 uppercase tracking-[0.2em] mb-1 block">{course.level}</span>
                  <h5 className="text-2xl font-black text-gray-900 tracking-tight">DSA SMART START {course.name}</h5>
                </div>
                <p className="text-gray-500 leading-relaxed mb-8 text-sm">
                  {course.desc}
                </p>
                <div className="pt-8 border-t border-gray-50 flex items-center justify-between">
                   <button className="text-[11px] font-black uppercase tracking-widest text-purple-600 flex items-center gap-2 group-hover:gap-4 transition-all">
                     View Details
                     <ChevronRight size={14} />
                   </button>
                   <Star size={16} className="text-gray-200" />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Kids Section */}
        <div>
          <div className="flex items-center gap-6 mb-12">
            <h4 className="text-sm font-black text-gray-400 uppercase tracking-widest whitespace-nowrap">DSA Kids</h4>
            <div className="h-[1px] flex-grow bg-gradient-to-r from-gray-200 to-transparent"></div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {kidsCourses.map((course, i) => (
              <div key={i} className="group relative bg-white rounded-[2rem] p-10 border border-gray-100 shadow-sm hover:shadow-2xl hover:shadow-pink-200/20 transition-all duration-500">
                <div className={`w-14 h-14 rounded-2xl bg-gradient-to-br ${course.color} text-white flex items-center justify-center mb-8 shadow-lg shadow-pink-200 transform group-hover:-translate-y-2 transition-transform duration-500`}>
                  {course.icon}
                </div>
                <div className="mb-6">
                  <span className="text-[10px] font-black text-pink-500 uppercase tracking-[0.2em] mb-1 block">{course.level}</span>
                  <h5 className="text-2xl font-black text-gray-900 tracking-tight">KIDS {course.name}</h5>
                </div>
                <p className="text-gray-500 leading-relaxed mb-8 text-sm">
                  {course.desc}
                </p>
                <div className="pt-8 border-t border-gray-50 flex items-center justify-between">
                   <button className="text-[11px] font-black uppercase tracking-widest text-pink-600 flex items-center gap-2 group-hover:gap-4 transition-all">
                     View Details
                     <ChevronRight size={14} />
                   </button>
                   <Star size={16} className="text-gray-200" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default CoursesSection;
