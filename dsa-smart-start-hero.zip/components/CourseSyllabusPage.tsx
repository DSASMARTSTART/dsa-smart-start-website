
import React, { useEffect, useRef } from 'react';
import { ArrowLeft, CheckCircle2, Star, Clock, Sparkles, BookOpen, Target, GraduationCap, ChevronRight, Zap, Lock, ShoppingCart, Check, Rocket, Shield } from 'lucide-react';

interface Module {
  title: string;
  topics: string[];
}

interface CourseData {
  id: string;
  name: string;
  level: string;
  description: string;
  duration: string;
  price: string;
  color: string;
  outcomes: string[];
  modules: Module[];
}

const SYLLABUS_DATA: Record<string, CourseData> = {
  "premium-path": {
    id: "premium-path",
    name: "PREMIUM PATH",
    level: "Elite Training",
    description: "The ultimate all-in-one mastery program. Designed for those who want no limits on their English potential, combining all levels with executive coaching and priority support.",
    duration: "Lifetime Access",
    price: "730.00€",
    color: "from-purple-600 to-indigo-800",
    outcomes: ["Full bilingual proficiency", "Executive communication skills", "Complete DSA strategy toolkit", "All-level certification eligibility"],
    modules: [
      { title: "The Master Foundation", topics: ["All A1-B1 Core Structures", "Advanced Executive Vocabulary", "Public Speaking for Dyslexics"] },
      { title: "Cognitive Mastery", topics: ["Speed Reading for Neurodiversity", "Deep Memory Encoding", "Strategic Note-Taking"] },
      { title: "Global Fluency", topics: ["Cross-cultural Communication", "Negotiation in English", "Presentation Mastery"] }
    ]
  },
  "gold-path": {
    id: "gold-path",
    name: "GOLD PATH",
    level: "Professional",
    description: "A comprehensive journey from beginner to intermediate mastery. The Gold Path focuses on long-term retention and real-world professional usage with bespoke study plans.",
    duration: "24 Months",
    price: "626.00€",
    color: "from-amber-400 to-amber-600",
    outcomes: ["Fluent professional conversation", "Business writing excellence", "Exam preparation mastery", "Self-Correction strategies"],
    modules: [
      { title: "Foundation to Fluency", topics: ["A1 & A2 Integrated Review", "B1 Expansion Modules", "Professional Vocabulary"] },
      { title: "Visual Logic", topics: ["Advanced Grammar Visualization", "Scenario-based Problem Solving", "Contextual Decoding"] },
      { title: "The Exam Bridge", topics: ["Cambridge & IELTS Prep", "Writing Workflows", "Time-management for Exams"] }
    ]
  },
  "a1": {
    id: "a1",
    name: "A1 LEVEL",
    level: "Beginner",
    description: "Designed to guide students with DSA through their first steps in learning English. A visual, multisensory, and inclusive approach that makes learning intuitive and gradual. Suitable for students aged 8 and up, following Cambridge English A1 preparation.",
    duration: "12 Weeks",
    price: "50.00€",
    color: "from-blue-500 to-indigo-600",
    outcomes: ["Basic daily conversations", "Visual alphabet decoding", "Subject pronouns mastery", "Recognition of 500+ words"],
    modules: [
      { title: "Foundations of Being", topics: ["Unit 1: Subject pronouns & Verb TO BE", "Unit 2: Regular & Irregular plural nouns", "Unit 3: Past simple of Verb TO BE", "Unit 4: Saxon genitive & 'Whose'", "Unit 5: Demonstratives (this, that, these, those)"] },
      { title: "Daily Expression", topics: ["Unit 6: Past simple of Verb TO BE (consolidation)", "Unit 7: Present simple & Frequency adverbs", "Unit 8: Past simple regular/irregular verbs", "Unit 9: Imperative forms", "Unit 10: Modal verb WILL"] },
      { title: "Advanced Basics", topics: ["Unit 11: Modal verbs CAN and COULD", "Unit 12: Object pronouns", "Unit 13: Have and have got", "Unit 14: Prepositions of time and place", "Unit 15: Present continuous"] }
    ]
  },
  "a2": {
    id: "a2",
    name: "A2 LEVEL",
    level: "Elementary",
    description: "Supports students with DSA in consolidating skills and introducing complex grammar. Visual and inclusive units facilitate comprehension and active language use. Follows Cambridge English A2 Key (KET) preparation, suitable for ages 9 and up.",
    duration: "16 Weeks",
    price: "1.00€",
    color: "from-indigo-500 to-purple-600",
    outcomes: ["Detailed scenario communication", "Effective use of past continuous", "Quantifier fluency", "Cambridge KET readiness"],
    modules: [
      { title: "Narrative & Flow", topics: ["Unit 1: Present simple vs present continuous", "Unit 2: Past continuous", "Unit 3: Past continuous vs past simple", "Unit 4: Adverbs & Prepositions", "Unit 5: Articles & Countable/Uncountable nouns"] },
      { title: "Quantifying My World", topics: ["Unit 6: Introduction to quantifiers (some, any)", "Unit 7: Advanced quantifiers (much, many, few)", "Unit 8: Comparative & Superlative adjectives", "Unit 9: Modal verbs MAY and MIGHT", "Unit 10: Modal verbs SHOULD, MUST, HAVE TO"] },
      { title: "Complex Patterns", topics: ["Unit 11: Verb patterns (like, want, remember)", "Unit 12: Future forms (will, going to, continuous)", "Unit 13: Present perfect simple", "Unit 14: Present perfect vs past simple", "Unit 15: Zero & First conditional; unless"] }
    ]
  },
  "b1": {
    id: "b1",
    name: "B1 LEVEL",
    level: "Intermediate",
    description: "An intermediate stage where language becomes a complex expressive tool. Promotes listening, reading, writing, and speaking through visual structure and simplified language. Follows Cambridge English B1 Preliminary (PET) prep.",
    duration: "20 Weeks",
    price: "50.00€",
    color: "from-purple-600 to-pink-600",
    outcomes: ["Independent professional communication", "Nuanced reporting skills", "Advanced causative usage", "Cambridge PET certification prep"],
    modules: [
      { title: "Temporal Mastery", topics: ["Unit 1: Present perfect continuous", "Unit 2: Perfect simple vs continuous", "Unit 3: Past perfect simple", "Unit 4: Future continuous", "Unit 5: Passive voice (Present, Past, Future)"] },
      { title: "Deduction & Reporting", topics: ["Unit 6: Causative (have/get something done)", "Unit 7: Advanced modals (ought to, shall, able to)", "Unit 8: Deduction (can't, must)", "Unit 9: Deduction (must, might, should)", "Unit 10: Reported speech"] },
      { title: "Nuance & Debate", topics: ["Unit 11: Indirect questions", "Unit 12: Second & Third conditional", "Unit 13: Relative pronouns & clauses", "Unit 14: Question tags", "Unit 15: Advanced comparative adjectives"] }
    ]
  },
  "kids-basic": {
    id: "kids-basic",
    name: "KIDS BASIC",
    level: "Early Years",
    description: "Designed to accompany children step-by-step. Progress from A1 Starters with activities that build confidence and basic communication through structured play.",
    duration: "8 Weeks",
    price: "19.00€",
    color: "from-pink-400 to-rose-500",
    outcomes: ["Early confidence in English", "Animal & Color vocabulary", "Basic sound association", "Positive attitude toward learning"],
    modules: [
      { title: "The Sound Adventure", topics: ["Unit 1: Interactive alphabet", "Unit 2: My Family icons", "Unit 3: Animal sounds map", "Unit 4: Color coding game", "Unit 5: Basic greetings"] },
      { title: "My Daily Play", topics: ["Unit 6: Toy vocabulary", "Unit 7: Action verbs (Jump, Run)", "Unit 8: Body parts song", "Unit 9: Classroom objects", "Unit 10: Simple food icons"] },
      { title: "First Sentences", topics: ["Unit 11: I like / I don't like", "Unit 12: Primary emotions", "Unit 13: Weather symbols", "Unit 14: Clothing icons", "Unit 15: Final review game"] }
    ]
  },
  "kids-advanced": {
    id: "kids-advanced",
    name: "KIDS ADVANCED",
    level: "Pre-Teen",
    description: "Completes the program offering essential content for Cambridge A2 Flyers exam. Develop the ability to understand complex sentences and realistic dialogues.",
    duration: "16 Weeks",
    price: "70.00€",
    color: "from-orange-500 to-amber-500",
    outcomes: ["Cambridge Flyers readiness", "Complex sentence structure", "Independent story reading", "Fluent realistic dialogues"],
    modules: [
      { title: "Time & Modality", topics: ["Unit 1: Past simple vs past continuous", "Unit 2: Modal verbs MAY, MIGHT, SHALL", "Unit 3: WILL for future", "Unit 4: BE GOING TO for plans", "Unit 5: Will vs Be Going To"] },
      { title: "Perfecting My Skills", topics: ["Unit 6: Present perfect simple (Aff/Neg)", "Unit 7: Present perfect simple (Question)", "Unit 8: Present perfect with common expressions", "Unit 9: Intermediate comparatives", "Unit 10: Possessive pronouns"] },
      { title: "Logic & Preference", topics: ["Unit 11: Preferences (like, love, hate + -ing)", "Unit 12: Adverbs ending in -ly", "Unit 13: First conditional mapping", "Unit 14: Second conditional mapping", "Unit 15: First vs Second conditional"] }
    ]
  }
};

interface SyllabusProps {
  courseId: string;
  onBack: () => void;
  onEnroll: (id: string) => void;
  onAddToCart: (id: string) => void;
  isInCart: boolean;
}

const CourseSyllabusPage: React.FC<SyllabusProps> = ({ courseId, onBack, onEnroll, onAddToCart, isInCart }) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const data = SYLLABUS_DATA[courseId];

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let particles: { x: number; y: number; size: number; speedX: number; speedY: number; opacity: number }[] = [];
    const particleCount = 30;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
      particles = Array.from({ length: particleCount }, () => ({
        x: Math.random() * canvas.width,
        y: Math.random() * canvas.height,
        size: Math.random() * 2 + 1,
        speedX: (Math.random() - 0.5) * 0.2,
        speedY: (Math.random() - 0.5) * 0.2,
        opacity: Math.random() * 0.4 + 0.1,
      }));
    };

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      particles.forEach((p) => {
        p.x += p.speedX;
        p.y += p.speedY;
        if (p.x > canvas.width) p.x = 0;
        if (p.x < 0) p.x = canvas.width;
        if (p.y > canvas.height) p.y = 0;
        if (p.y < 0) p.y = canvas.height;
        ctx.fillStyle = `rgba(168, 85, 247, ${p.opacity})`;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
      });
      animationFrameId = requestAnimationFrame(animate);
    };

    window.addEventListener('resize', resize);
    resize();
    animate();
    return () => {
      window.removeEventListener('resize', resize);
      cancelAnimationFrame(animationFrameId);
    };
  }, []);

  if (!data) return <div className="p-20 text-center">Course not found.</div>;

  return (
    <div className="bg-white min-h-screen">
      {/* Syllabus Hero */}
      <div className="relative w-full h-[60vh] min-h-[500px] flex flex-col items-center justify-center overflow-hidden bg-[#f8f5ff]">
        <div className="absolute inset-0 z-0">
          <canvas ref={canvasRef} className="absolute inset-0 z-0 pointer-events-none" />
          <div className="absolute inset-0 opacity-15 pointer-events-none" 
               style={{ backgroundImage: `repeating-linear-gradient(90deg, transparent, transparent 45px, rgba(255, 255, 255, 0.4) 50px, transparent 55px, transparent 100px)`, filter: 'blur(30px)' }} />
        </div>

        <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6">
          <button 
            onClick={onBack}
            className="group absolute top-0 left-4 sm:left-6 flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-gray-500 hover:text-purple-600 transition-colors"
          >
            <ArrowLeft size={16} className="group-hover:-translate-x-1 transition-transform" />
            Back to Courses
          </button>

          <div className="flex flex-col items-center text-center mt-12">
            <div className="flex items-center gap-4 mb-6 opacity-60 animate-reveal">
              <div className="h-[1.5px] w-8 sm:w-12 bg-purple-400"></div>
              <span className="text-[10px] sm:text-[11px] font-black uppercase tracking-[0.4em] text-gray-800 uppercase">Premium Curriculum</span>
              <div className="h-[1.5px] w-8 sm:w-12 bg-purple-400"></div>
            </div>

            <h1 className="flex flex-wrap items-center justify-center gap-x-2 sm:gap-x-4 text-4xl sm:text-6xl md:text-8xl lg:text-[9rem] font-black text-[#1a1c2d] tracking-tighter leading-none animate-reveal transition-transform duration-500 uppercase">
              <span>{data.name.split(' ')[0]}</span>
              <span className={`italic text-transparent bg-clip-text bg-gradient-to-r ${data.color} drop-shadow-sm px-2 sm:px-4`}>
                {data.name.split(' ').slice(1).join(' ')}
              </span>
            </h1>

            <div className="max-w-3xl mt-8 sm:mt-10 animate-reveal stagger-1 px-4">
              <p className="text-lg sm:text-2xl font-light italic text-gray-700 leading-tight">
                {data.description}
              </p>
            </div>

            {/* SYLLABUS PAGE HERO BUTTONS */}
            <div className="flex flex-wrap justify-center gap-4 mt-10 sm:mt-12 animate-reveal stagger-2">
               <button 
                  onClick={() => onEnroll(courseId)}
                  className={`flex items-center gap-3 px-10 sm:px-14 py-4 sm:py-6 rounded-full text-[10px] sm:text-xs font-black uppercase tracking-widest text-white shadow-2xl hover:scale-105 transition-all bg-gradient-to-r ${data.color}`}
               >
                  ENROLL FOR {data.price}
                  <ChevronRight size={16} />
               </button>
               <button 
                  onClick={() => onAddToCart(courseId)}
                  className={`flex items-center gap-3 px-8 sm:px-10 py-4 sm:py-6 rounded-full text-[9px] sm:text-[10px] font-black uppercase tracking-widest border-2 transition-all ${isInCart ? 'bg-green-50 border-green-500 text-green-600' : 'bg-white border-gray-100 text-gray-400 hover:border-purple-200 hover:text-purple-600'}`}
               >
                  {isInCart ? <><Check size={16} /> Added to Cart</> : <><ShoppingCart size={16} /> Add to Cart</>}
               </button>
            </div>
          </div>
        </div>

        {/* Curved Bottom Mask */}
        <div 
          className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[160%] h-[150px] sm:h-[200px] bg-white z-20"
          style={{ borderRadius: '100% 100% 0 0', transform: 'translateX(-50%) translateY(50%)' }}
        />
      </div>

      {/* Main Detail Section */}
      <section className="pb-32 px-6 relative z-30">
        <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-16 lg:gap-24">
          
          {/* Left: Outcomes & Highlights */}
          <div className="lg:col-span-5 space-y-16 animate-reveal">
            <div>
              <div className="flex items-center gap-3 mb-6">
                <div className="p-3 bg-purple-50 rounded-2xl text-purple-600 border border-purple-100">
                  <GraduationCap size={28} />
                </div>
                <h3 className="text-3xl font-black text-gray-900 tracking-tight uppercase">What You'll Master</h3>
              </div>
              <p className="text-gray-500 text-lg mb-8 font-medium">
                Our curriculum is built to ensure tangible progress. By the end of this level, you will have achieved:
              </p>
              <div className="space-y-4">
                {data.outcomes.map((item, i) => (
                  <div key={i} className="flex items-center gap-4 p-5 bg-gray-50 rounded-[2rem] border border-gray-100 group hover:bg-white hover:border-purple-200 transition-all">
                    <CheckCircle2 className="text-green-500 shrink-0" size={20} />
                    <span className="text-sm font-bold text-gray-700">{item}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="p-10 bg-gradient-to-br from-[#1a1c2d] to-black rounded-[3rem] text-white relative overflow-hidden group">
              <div className="absolute top-0 right-0 w-32 h-32 bg-purple-600/20 rounded-full blur-[60px] translate-x-1/2 -translate-y-1/2"></div>
              <div className="relative z-10">
                <Sparkles className="text-purple-400 mb-6" size={32} />
                <h4 className="text-2xl font-black mb-4 uppercase tracking-tight">The DSA Advantage</h4>
                <p className="text-gray-400 text-sm leading-loose mb-8">
                  Unlike traditional syllabuses, we don't just list grammar points. We teach you <span className="text-white italic underline underline-offset-4 decoration-purple-500 decoration-2">how to learn</span> through visual pegs and sensory triggers.
                </p>
                <div className="space-y-2">
                   {["Visual Mind Mapping", "Audio Memory Pegs", "Kinesthetic Learning Blocks"].map((tag, i) => (
                     <div key={i} className="inline-block px-4 py-2 bg-white/5 rounded-full border border-white/10 text-[10px] font-black uppercase tracking-widest mr-2 mb-2">{tag}</div>
                   ))}
                </div>
              </div>
            </div>
          </div>

          {/* Right: Modules Timeline */}
          <div className="lg:col-span-7 animate-reveal stagger-1">
            <div className="flex items-center gap-3 mb-10">
              <div className="p-3 bg-indigo-50 rounded-2xl text-indigo-600 border border-indigo-100">
                <BookOpen size={28} />
              </div>
              <h3 className="text-3xl font-black text-gray-900 tracking-tight uppercase">Course Roadmap</h3>
            </div>

            <div className="relative pl-8 md:pl-12 border-l-2 border-dashed border-gray-100 space-y-12">
              {data.modules.map((module, i) => (
                <div key={i} className="relative group">
                  {/* Timeline Dot */}
                  <div className={`absolute -left-[41px] md:-left-[49px] top-0 w-4 h-4 rounded-full border-4 border-white bg-gradient-to-r ${data.color} ring-4 ring-gray-50 group-hover:scale-150 transition-transform duration-500 shadow-sm z-10`}></div>
                  
                  <div className="bg-white p-8 md:p-10 rounded-[3rem] border border-gray-100 shadow-sm hover:shadow-xl hover:shadow-purple-500/5 transition-all duration-500 overflow-hidden relative">
                    <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-6">
                      <h5 className="text-2xl font-black text-gray-900 tracking-tight uppercase">Module 0{i+1}: {module.title}</h5>
                      <div className="px-4 py-1.5 bg-gray-50 rounded-full border border-gray-100 text-[10px] font-black uppercase tracking-widest text-gray-400">
                        {i === 0 ? "Introduction" : "Level Milestone"}
                      </div>
                    </div>
                    
                    <div className="relative min-h-[80px]">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {module.topics.map((topic, j) => (
                          <div key={j} className="flex items-start gap-3">
                            <div className={`w-2 h-2 mt-1.5 rounded-full shrink-0 bg-gradient-to-r ${data.color}`}></div>
                            <span className="text-xs font-bold text-gray-600 leading-tight">{topic}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* BOTTOM CTAs FOR THE SYLLABUS PAGE */}
            <div className="mt-20 p-12 bg-gray-50 rounded-[4rem] border border-gray-100 text-center animate-reveal">
               <h4 className="text-2xl font-black text-gray-900 mb-4 uppercase tracking-tight">Ready to start this level?</h4>
               <p className="text-gray-500 mb-10 font-medium">Join our community and transform your learning journey today.</p>
               <div className="flex flex-col sm:flex-row justify-center gap-4">
                  <button 
                    onClick={() => onEnroll(courseId)}
                    className={`flex items-center justify-center gap-3 px-10 py-5 rounded-full text-xs font-black uppercase tracking-widest text-white shadow-xl hover:scale-105 transition-all bg-gradient-to-r ${data.color}`}
                  >
                    ENROLL FOR {data.price}
                    <ChevronRight size={18} />
                  </button>
                  <button 
                    onClick={() => onAddToCart(courseId)}
                    className={`flex items-center justify-center gap-3 px-8 py-5 rounded-full text-[10px] font-black uppercase tracking-widest border-2 transition-all ${isInCart ? 'bg-green-50 border-green-500 text-green-600' : 'bg-white border-gray-100 text-gray-400 hover:border-purple-200 hover:text-purple-600'}`}
                  >
                    {isInCart ? <><Check size={18} /> Added to Cart</> : <><ShoppingCart size={18} /> Add to Cart</>}
                  </button>
               </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default CourseSyllabusPage;
